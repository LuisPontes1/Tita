import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns

class TaylorBoostRegressor:
    
    def __init__(self, grau_max = 2, max_termos = None, passo = 1,
                 alph_eps = [0.1, 0.1], gpu = False, n_jobs = None):
        self.__grau_max = grau_max
        self.__max_termos = max_termos
        self.__passo = passo
        if isinstance(alph_eps, list):
            self.__alpha = alph_eps[0]
            self.__epsilon = alph_eps[1]
        else:
            self.__alpha = None
            self.__epsilon = None
        self.__gpu = gpu
        self.__n_jobs = n_jobs
        if(self.__gpu):
            import cupy as cp #pip install cupy-cuda112
            self.__mempool = cp.get_default_memory_pool()
            self.__pinned_mempool = cp.get_default_pinned_memory_pool()
        
        #OBS: Note que por conta do epsilon e do alpha, dados normalizados são melhores de otimizar
        #E assim mais fácil de rodar o algoritmo
    
    def __limpa_memoria_gpu(self):
        self.__mempool.free_all_blocks()
        self.__pinned_mempool.free_all_blocks()  
    
    def __checa_X_predict(self, X):
        if isinstance(X, pd.DataFrame):
            X = X.values
        else:
            try:
                if len(X.shape) != 2:
                    print("Valores de entrada de predição não adequados")
                    return
            except:
                print("Valores de entrada de predição não adequados")
                return
        return X
    
    def __checa_X_e_y_treino(self, X, y):
        if isinstance(X, pd.DataFrame):
            self.__X = X.values
            self.__nome_vars = X.columns.values
        else:
            try:
                if len(X.shape) == 2:
                    self.__X = X
                else:
                    print("Valores de entrada de treino não adequados")
                    return
            except:
                print("Valores de entrada de treino não adequados")
                return
        self.__num_linhas = self.__X.shape[0]
        self.__num_cols = self.__X.shape[1]
        
        if (isinstance(y, pd.DataFrame) and len(y.columns) == 1) or (isinstance(y, pd.Series)):
            self.__y = y.values
        else:
            try:
                if len(y.shape) == 1:
                    self.__y = y
                else:
                    print("Valores de alvo de treino não adequados")
                    return
            except:
                print("Valores de alvo de treino não adequados")
                return
        if(self.__y.size != self.__num_linhas):
            print("Quantidade de exemplos não coindicem em X e y")
            return
            
    def __checa_conjunto_validacao(self, conj_val):
        #Verifica se foi passado um conjunto de validação
        if conj_val != None:
            if isinstance(conj_val, tuple):
                if(len(conj_val) == 2):
                    if isinstance(conj_val[0], pd.DataFrame):
                        self.__Xval = conj_val[0].values
                    else:
                        try:
                            if len(conj_val[0].shape) == 2:
                                self.__Xval = conj_val[0]
                            else:
                                print("Valores de entrada de validação não adequados")
                                return
                        except:
                            print("Valores de entrada não adequados")
                            return
                        
                    if (isinstance(conj_val[1], pd.DataFrame) and len(conj_val[1].columns) == 1) or (isinstance(conj_val[1], pd.Series)):
                        self.__yval = conj_val[1].values
                    else:
                        try:
                            if len(conj_val[1].shape) == 1:
                                self.__yval = conj_val[1]
                            else:
                                print("Valores de alvo de validação não adequados")
                                return
                        except:
                            print("Valores de alvo de validação não adequados")
                            return
                        
                else:
                    print("Valores de validação não adequados")
                    return
            else:
                print("Valores de validação não adequados")
                return
            self.__tem_validacao = True
        else:
            self.__tem_validacao = False
    
    def __guarda_melhor_modelo(self, r2_val):
        #Guarda o modelo atual nas variáveis de melhor modelo
        self.__vars_selec_melhor = self.__vars_selec
        self.__num_termos_melhor = self.__num_termos
        self.__y_pred_melhor = self.__y_pred
        self.__diff_melhor = self.__diff
        self.__thetas_melhor = self.__thetas
        self.__gradiente_melhor = self.__gradiente
        self.__r2_val_melhor = r2_val      
        
    def __calcula_r2(self, diff, mse_baseline):
        if(self.__gpu):
            r2 = 1 - float(cp.mean(diff**2))/mse_baseline
        else:
            r2 = 1 - np.mean(diff**2)/mse_baseline
        return r2
    
    def __calcula_predicoes(self, thetas, X):
        if(self.__gpu):
            self.__limpa_memoria_gpu()
            y_pred = thetas[0] + cp.dot(X, cp.array(thetas[1:]))
        else:
            y_pred = thetas[0] + np.dot(X, thetas[1:])
        return y_pred
        
    def __derivada_parcial_custo(self, diff, vetor_x):
        #Implementa o calculo da derivada parcial da função de custo
        if(self.__gpu):
            return float(cp.sum(diff*vetor_x)/diff.size)
        else:
            return np.sum(diff*vetor_x)/diff.size
    
    def __ajusta_predicoes(self, vars_der_add, thetas_add):
        if(self.__gpu):
            self.__limpa_memoria_gpu()
            yn_pred_add = cp.dot(self.__X[:, vars_der_add], cp.array(thetas_add))
            self.__y_pred = self.__y_pred + yn_pred_add #Muda as predições com os novos thethas
        else:
            yn_pred_add = np.dot(self.__X[:, vars_der_add], thetas_add)
            self.__y_pred = self.__y_pred + yn_pred_add #Muda as predições com os novos thethas
    
    def __calcula_derivadas(self):
        if(self.__gpu):
            der_parciais = np.array([float(cp.mean(self.__diff))]) #Derivada parcial do termo theta_0
            der_parciais_resto = np.array([self.__derivada_parcial_custo(self.__diff, self.__X[:, v]) 
                                           for v in self.__vars_selec])
            der_parciais = np.append(der_parciais, der_parciais_resto)
        else:
            der_parciais = np.array([np.mean(self.__diff)]) #Derivada parcial do termo theta_0
            der_parciais_resto = np.array([self.__derivada_parcial_custo(self.__diff, self.__X[:, v]) 
                                           for v in self.__vars_selec])
            der_parciais = np.append(der_parciais, der_parciais_resto)
        return der_parciais
    
    def __descida_gradiente(self, derivadas_add, vars_der_add):
        alpha = self.__alpha
        gradiente_referencia = (self.__gradiente**2 + np.sum(derivadas_add**2))**0.5
        #Calcula o gradiente que aparece a mais só por considerarmos esse termo a mais
        #mesmo se considerarmos o valor do seu coeficiente como zero (referencia para alterar alpha)
    
        #Passo Zero
        thetas_add = -alpha * derivadas_add
        self.__thetas = np.append(self.__thetas, thetas_add) #Adiciona os novos thetas
        self.__ajusta_predicoes(vars_der_add, thetas_add)
        self.__diff = self.__y_pred - self.__y #Calcula as diferenças entre predito e label
        der_parciais = self.__calcula_derivadas()
        self.__gradiente = np.sum(der_parciais**2)**0.5
        if(self.__gradiente > gradiente_referencia):
            alpha = alpha/2 #Diminui o alpha se o passo foi muito grande: aumentou o gradiente
        else:
            alpha = self.__alpha
            gradiente_referencia = self.__gradiente
    
        #Loop de outros passos até a convengência exigida: isto é, o valor epsilon
        while(self.__gradiente >= self.__epsilon):
            self.__thetas = self.__thetas - alpha * der_parciais #Adiciona os novos thetas
            self.__y_pred = self.__calcula_predicoes(self.__thetas, self.__X[:, self.__vars_selec])
            self.__diff = self.__y_pred - self.__y #Calcula as diferenças entre predito e label
            der_parciais = self.__calcula_derivadas()
            self.__gradiente = np.sum(der_parciais**2)**0.5
            if(self.__gradiente > gradiente_referencia):
                alpha = alpha/2 #Diminui o alpha se o passo foi muito grande: aumentou o gradiente
            else:
                alpha = self.__alpha
                gradiente_referencia = self.__gradiente
    
    def fit(self, X, y, conj_val = None, nome_vars = None):
        self.__nome_vars = nome_vars
        self.__checa_X_e_y_treino(X, y)
        self.__checa_conjunto_validacao(conj_val)
        
        #Gera os termos polinomiais nos dados
        if(self.__grau_max > 1):
            self.__exp_taylor = PolynomialFeatures(degree = self.__grau_max, include_bias = False)
            self.__exp_taylor = self.__exp_taylor.fit(self.__X)
            self.__X = self.__exp_taylor.transform(self.__X)
            if(self.__tem_validacao):
                self.__Xval = self.__exp_taylor.transform(self.__Xval)
        
        #Faz a normalização
        #Facilita calculo de Inv. de Matriz e também facilita a Descida do Gradiente
        self.__means = np.mean(self.__X, axis = 0)
        self.__stds = np.mean((self.__X - self.__means)**2, axis = 0)**0.5
        self.__stds = np.array([v if v > 0 else 1 for v in self.__stds]) #Quando o desvio padrão é 0 
        self.__X = (self.__X - self.__means)/self.__stds
        if(self.__tem_validacao):
            self.__Xval = (self.__Xval - self.__means)/self.__stds
        
        #Normaliza o y também: acho que ajuda na Descida do Gradiente
        self.__media_y = np.mean(self.__y)
        self.__desvio_y = np.mean((self.__y - self.__media_y)**2)**0.5
        self.__y = (self.__y - self.__media_y)/self.__desvio_y
        if(self.__tem_validacao):
            self.__yval = (self.__yval - self.__media_y)/self.__desvio_y
        
        #Faz o modelo baseline: só o termo theta_0 -> cte!
        self.__vars_selec = np.array([]).astype(int) #Lista das variaveis selecionadas no regressor
        self.__num_termos = 1 #Número de termos do regressor
        self.__y_pred = np.repeat(np.mean(self.__y), self.__y.size) #predição do baseline
        self.__diff = self.__y_pred - self.__y #Diferenças entre o real e o predito
        self.__thetas = np.array([self.__y_pred[0]]) #Valor dos thetas do regressor
        self.__gradiente = 0 #No caso o gradiente é zero pq foi o mínimo exato
        
        #Salva o mse do modelo baseline (só constante)
        self.__mse_baseline = np.mean(self.__diff**2)
        if(self.__tem_validacao):
            self.__mse_baseline_val = np.mean((self.__yval - self.__thetas[0])**2)
        
        #####
        ##### Algoritmo em loop incremental estilo Boosting para aumentar a complexidade #####
        #####
        
        #Converte para fazer as contas mais pesadas em GPU
        if(self.__gpu and self.__epsilon != None):
            self.__limpa_memoria_gpu()
            self.__X = cp.array(self.__X)
            self.__y = cp.array(self.__y)
            if(self.__tem_validacao):
                self.__Xval = cp.array(self.__Xval)
                self.__yval = cp.array(self.__yval)
            self.__y_pred = cp.array(self.__y_pred)
            self.__y_pred = cp.array(self.__y_pred)
            self.__diff = cp.array(self.__diff)
        
        #Inicializamos as variaveis para criar a curva viés-variância
        self.__curva_num_termos = np.array([self.__num_termos])
        self.__curva_r2 = np.array([0])
        if(self.__tem_validacao):
            self.__curva_r2_val = np.array([0])
            self.__guarda_melhor_modelo(0)
            
        vars_disp = np.arange(self.__X.shape[1]) #vetor com as variaveis disponíveis para escolher
        if(self.__max_termos == None):
            self.__max_termos = vars_disp.size + 1 #Considera todos os termos se não tiver dado limite
        else:
            self.__max_termos = min(self.__max_termos, vars_disp.size + 1)

        #Loop do processo incremental de adição de termos na regressão
        while(self.__num_termos < self.__max_termos and vars_disp.size > 0):
            #Calcula todos valores das derividas parciais dos termos que estão faltando na regressão
            derivadas_parciais = np.array([self.__derivada_parcial_custo(self.__diff, self.__X[:, v]) 
                                           for v in vars_disp])
            derivadas_parciais_abs = np.abs(derivadas_parciais) #Pega os valores da derivada em módulo
            inds_ordena_derivadas = np.argsort(derivadas_parciais_abs)[::-1] #Ordena decrescente
            pos_der_add = inds_ordena_derivadas[:min(self.__passo, vars_disp.size)]
            vars_der_add = vars_disp[pos_der_add] #Lista das respectivas vars
            #Adiciona essas variaveis no regressor: Note que o passo define quantas vars add por vez
            self.__vars_selec = np.append(self.__vars_selec, vars_der_add)
            self.__num_termos = self.__num_termos + self.__passo
            vars_disp = np.delete(vars_disp, pos_der_add) #Remove essas variaveis das disponíveis
            #Isto é, a ideia aqui foi incrementar o regressor com a variável que mais vai "bagunçar"
            # o mínimo que já haviamos encontrado para a Função de Custo: ou seja, deriv. parcial max.
            
            if(self.__epsilon == None):
                #Resolve analiticamente (solução exata)
                reg = LinearRegression(n_jobs = self.__n_jobs).fit(self.__X[:, self.__vars_selec], 
                                                                   self.__y)
                self.__y_pred = reg.predict(self.__X[:, self.__vars_selec])
                self.__diff = self.__y_pred - self.__y #Diferenças entre o real e o predito
                self.__thetas = np.insert(reg.coef_, 0, reg.intercept_)
                self.__gradiente = 0
            else:
                ###### Otimiza os thetas pelo algoritmo de Descida do Gradiente ######
                self.__descida_gradiente(derivadas_parciais[pos_der_add], vars_der_add)
            
            #Calcula os MSE e adiciona na curva de Viés-Variância
            self.__curva_num_termos = np.append(self.__curva_num_termos, self.__num_termos)
            r2 = self.__calcula_r2(self.__diff, self.__mse_baseline)
            self.__curva_r2 = np.append(self.__curva_r2, r2)
            if(self.__tem_validacao):
                yval_pred = self.__calcula_predicoes(self.__thetas, self.__Xval[:,self.__vars_selec])
                diff_val = yval_pred - self.__yval
                r2_val = self.__calcula_r2(diff_val, self.__mse_baseline_val)
                self.__curva_r2_val = np.append(self.__curva_r2_val, r2_val)
                #Vê se encontramos um novo melhor modelo e guarda ele
                if(r2_val > self.__r2_val_melhor):
                    self.__guarda_melhor_modelo(r2_val)
                
                print(str(r2) + " / " + str(r2_val) + " (" + str(self.__num_termos_melhor) + ")")
            else:
                print(str(r2) + " (" + str(self.__num_termos) + ")")
        
        if(self.__gpu and self.__epsilon != None):
            self.__X = cp.asnumpy(self.__X)
            self.__limpa_memoria_gpu()
        
        #####
        ##### Fim do loop do algoritmo incremental #####
        #####
        
        #Calcula importancias das variáveis selecionadas e pega seus nomes nas expansão de taylor
        self.__calcula_importancias()
        self.__traduz_nomes_vars()
        
    def predict(self, X):
        X = self.__checa_X_predict( X)
        if(self.__grau_max > 1):
            X = self.__exp_taylor.transform(X)
        X = (X - self.__means)/self.__stds
        if(self.__tem_validacao):
            y_pred = self.__thetas_melhor[0] + np.dot(X[:, self.__vars_selec_melhor],
                                                      self.__thetas_melhor[1:])
        else:
            y_pred = self.__thetas[0] + np.dot(X[:, self.__vars_selec], self.__thetas[1:])
        y_pred = self.__media_y + self.__desvio_y*y_pred 
        return y_pred
    
    def grafico_vies_variancia(self, pos_ini = None, pos_fim = None, figsize = [8, 6]):        
        #Prepara os valores e vetores de plot
        if(pos_ini == None):
            pos_ini = 0
        if(pos_fim == None):
            pos_fim = self.__curva_num_termos.size
        curva_num_termos = self.__curva_num_termos[pos_ini:pos_fim]
        curva_r2 = self.__curva_r2[pos_ini:pos_fim]
        if(self.__tem_validacao):
            curva_r2_val = self.__curva_r2_val[pos_ini:pos_fim]
            r2_val_melhor = self.__r2_val_melhor
            r2_min = min(min(curva_r2), min(curva_r2_val))
        #Plota as curvas e o ponto de parada do treinamento pela validação
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            axs.plot(curva_num_termos, curva_r2, color = paleta_cores[0], label = 'Treino')
            if(self.__tem_validacao):
                axs.plot(curva_num_termos, curva_r2_val, color = paleta_cores[1], label = 'Validação')
                axs.vlines(self.__num_termos_melhor, r2_min, r2_val_melhor, color = 'k', 
                           linestyle = '--', label = 'Ponto de Parada')
            axs.set_xlabel('Número de Termos')
            axs.set_ylabel('R2')
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.show()

    def __calcula_importancias(self):
        if(self.__tem_validacao):
            vars_selec = self.__vars_selec_melhor
            thetas = self.__thetas_melhor
        else:
            vars_selec = self.__vars_selec
            thetas = self.__thetas
        if(self.__grau_max > 1):
            nomes_vars = np.array(self.__exp_taylor.get_feature_names())
        else:
            nomes_vars = np.array(['x'  + str(i) for i in range(0, self.__num_cols)])
        self.feature_names_ = np.array([nomes_vars[v] for v in vars_selec])
        coef_abs = np.abs(thetas[1:])
        self.feature_importances_ = coef_abs/np.sum(coef_abs)
    
    def __traduz_nomes_vars(self):
        if(isinstance(self.__nome_vars, np.ndarray)):
            chaves = ['x' + str(i) for i in range(self.__nome_vars.size)]
            dic_vars = dict(zip(chaves[::-1], self.__nome_vars[::-1]))
            def trocar(string, dic_vars):
                for chave, valor in dic_vars.items():
                    string = string.replace(chave, valor)
                return string
            self.feature_names_ = np.array([trocar(s, dic_vars) for s in self.feature_names_])
            
    def grafico_importancias(self, num_vars = None, figsize = [8, 6]):        
        if(num_vars == None):
            num_vars = self.__curva_num_termos.size
        vars_nomes = self.feature_names_
        vars_imp = self.feature_importances_
        inds_ordenado = np.argsort(vars_imp)[::-1]
        vars_nomes = vars_nomes[inds_ordenado[:num_vars]]
        vars_imp = vars_imp[inds_ordenado[:num_vars]]
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            axs.barh(vars_nomes[::-1], vars_imp[::-1], color = paleta_cores[0])
            axs.set_xlabel('Importância')
            axs.set_ylabel('Variável')
            plt.show()
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D

from AleTransforms import *

#Para funcionar direito, é preciso transformar os valores numéricos todos em float (não pode ter int, por exemplo)
class DistribuicoesDataset:

    def __init__(self, df, num_div = None, frac_cat = 0):
        self.__df = df
        self.__num_linhas = len(self.__df)
        self.__colunas = df.columns.values
        self.__num_colunas = self.__colunas.size
        
        self.__num_div = num_div
        self.__frac_cat = frac_cat
        
        self.__dict_flag_na = {}
        self.__dict_frac_na = {}
        self.__tipo_numerico = np.array([])
        self.__tipo_categorico = np.array([])
        
        for col in self.__colunas:
            self.__encontra_na(col)
        
        self.__tratadf = TrataDataset(self.__df, num_div = self.__num_div, frac_cat = self.__frac_cat, 
                                      features_numericas = list(self.__tipo_numerico), features_categoricas = list(self.__tipo_categorico))        
        self.__dict_intervs, self.__dict_filtroscat = self.__tratadf.retorna_instancias_tratamento()
    
    def info_dataset(self):
        return self.__num_linhas, self.__num_colunas, self.__colunas
        
    def retorna_trata_dataset(self):
        return self.__tratadf
    
    def retorna_flag_na(self, col_ref):
        return self.__dict_flag_na[col_ref]
    
    #Enquantra a quantidade e posições dos NA na coluna e separa as colunas por tipo
    def __encontra_na(self, col_ref):
        valores = self.__df[col_ref].values
        if(valores.dtype in [np.number, 'int64', 'float64']):
            flag_na = np.isnan(valores, where = True)
            self.__tipo_numerico = np.append(self.__tipo_numerico, col_ref)
        else:
            flag_na = pd.isna(self.__df[col_ref]).values
            self.__tipo_categorico = np.append(self.__tipo_categorico, col_ref)
        self.__dict_flag_na[col_ref] = flag_na
        self.__dict_frac_na[col_ref] = np.sum(flag_na)/self.__num_linhas
    
    def curva_distribuicao(self, col_ref):
        if(col_ref in self.__colunas):
            if(col_ref in self.__dict_intervs.keys()):
                valores, frac = self.__dict_intervs[col_ref].curva_distribuicao()
                tipo = 'intervalo'
                
            elif(col_ref in self.__dict_filtroscat.keys()):
                valores, frac = self.__dict_filtroscat[col_ref].curva_distribuicao()
                tipo = 'categoria'
            else:
                valores, qtds = np.unique(self.__df[col_ref].dropna().values, return_counts = True)
                frac = qtds/self.__num_linhas
                tipo = 'discreto'
            return valores, frac, tipo
    
    def grafico_distribuicao(self, col_ref = [], conv_str = True, figsize = [6, 4]):
        #Transforma uma string única em uma lista
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
        #Se não passar nada plota o gráfico de todas as colunas
        if(len(col_ref) == 0):
            colunas = self.__colunas
        else:
            colunas = col_ref
        
        #Para cada coluna
        for col_ref in colunas:
            if(col_ref in self.__colunas):
                paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
                
                frac_na = self.__dict_frac_na[col_ref]
                
                #Plota informações da distribuição da variável de referência nos dados
                with sns.axes_style("whitegrid"):
                    fig, axs = plt.subplots(1, 1, figsize = figsize)
                    valores, frac, tipo = self.curva_distribuicao(col_ref)
                    if(tipo == 'intervalo'):
                        axs.fill_between(valores, frac, color = paleta_cores[0], alpha = 0.5)
                        axs.plot(valores, frac, color = paleta_cores[0])
                        axs.set_ylabel('Fração/L')
                    elif(tipo == 'categoria'):
                        axs.bar(valores, frac, color = paleta_cores[0], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[0])
                        axs.set_ylabel('Fração')
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        axs.bar(valores, frac, color = paleta_cores[0], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[0])
                        axs.set_ylabel('Fração')
                    plt.gcf().text(1, 0.8, 'Fração de NA = ' + '%.2g' % frac_na, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                    axs.set_xlabel(col_ref)
                    axs.set_ylim(bottom = 0.0)
                    plt.show()
                    
##############################

##############################

class TendenciasAlvoDataset:

    def __init__(self, df, col_alvo, num_div = None, frac_cat = 0):
        
        self.distribuicoes = DistribuicoesDataset(df, num_div, frac_cat)
        self.__dict_intervs, self.__dict_filtroscat = self.distribuicoes.retorna_trata_dataset().retorna_instancias_tratamento()
        self.__df_tratado = self.distribuicoes.retorna_trata_dataset().aplica_transformacao(df, usar_ponto_medio = False, considera_resto = True, usar_str = False)
        
        self.__y = df[col_alvo].values
        self.__col_alvo = col_alvo
        
        self.__dict_valores = {}
        self.__dict_qtds = {}
        
        self.__dict_soma_alvo = {}
        self.__dict_media_alvo = {}
        
        self.__dict_tendencia = {}
        self.__dict_impacto = {}
        
        self.__calcula_metricas_condicionais()
        self.__calcula_tendencias()
    
    def __calcula_metricas_condicionais(self):
        _, _, colunas = self.distribuicoes.info_dataset()
        for col_ref in colunas:
            flag_na = self.distribuicoes.retorna_flag_na(col_ref)
            valores = self.__df_tratado.loc[~flag_na, col_ref].astype(int).values
            y = self.__y[~flag_na]
            
            inds_ordenado = np.argsort(valores)
            valores_unico, primeira_ocorrencia, qtds = np.unique(valores[inds_ordenado], return_index = True, return_counts = True)
            self.__dict_valores[col_ref] = valores_unico
            self.__dict_qtds[col_ref] = qtds
            
            y_agrup = np.split(y[inds_ordenado], primeira_ocorrencia[1:])
            soma_alvo = np.array([np.sum(v) for v in y_agrup])
            self.__dict_soma_alvo[col_ref] = soma_alvo
            self.__dict_media_alvo[col_ref] = soma_alvo/qtds

    def valor_metricas_condicionais(self, col_ref):
        _, _, colunas = self.distribuicoes.info_dataset()
        df = pd.DataFrame()
        if(col_ref in colunas):
            df['Valores'] = self.__dict_valores[col_ref]
            if(col_ref in self.__dict_intervs.keys()):
                df['Labels'] = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            elif(col_ref in self.__dict_filtroscat.keys()):
                df['Labels'] = self.__dict_filtroscat[col_ref].strings_categorias()
            df['QTD'] = self.__dict_qtds[col_ref]
            df['Soma_Alvo'] = self.__dict_soma_alvo[col_ref]
            df['Media_Alvo'] = self.__dict_media_alvo[col_ref]       
        return df
    
    def __curva_medias_condicional(self, col_ref):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
        medias_alvo = self.__dict_media_alvo[col_ref]
        
        #Ordena por média do alvo se forem categorias (e podemos rearranjar a ordem)
        if(tipo == 'categoria'):
            inds_ordenado = np.argsort(medias_alvo)
            valores = valores[inds_ordenado]
            labels = labels[inds_ordenado]
            medias_alvo = medias_alvo[inds_ordenado]
        
        return valores, labels, medias_alvo, tipo
    
    def grafico_medias_condicional(self, col_ref = [], conv_str = True, figsize = [6, 4]):
        _, _, colunas = self.distribuicoes.info_dataset()
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
        if(len(col_ref) != 0):
            colunas = col_ref
            
        for col_ref in colunas:
            if(col_ref in colunas):
                paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
                
                with sns.axes_style("whitegrid"):
                    fig, axs = plt.subplots(1, 1, figsize = figsize)
                    valores, labels, medias_alvo, tipo = self.__curva_medias_condicional(col_ref)
                    if(labels is not None):
                        if(tipo == 'intervalo'):
                            axs.bar(valores, medias_alvo, color = paleta_cores[0])
                            axs.set_xticks(valores)
                            axs.set_xticklabels(labels, rotation = 90)
                        elif(tipo == 'categoria'):
                            axs.bar(labels, medias_alvo, color = paleta_cores[0])
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        axs.bar(valores, medias_alvo, color = paleta_cores[0])
                    axs.set_xlabel(col_ref)
                    axs.set_ylabel('Média Alvo')
                    plt.show()
    
    def __calcula_tendencias(self):
    
        #Calculamos a derivada por aproximação de uma parábola (com os 2 pontos mais próximos)
        def calc_diff(vetor):
            if(vetor.size > 2):
                diferenca = np.array([(vetor[i+1] - vetor[i-1])*0.5 for i in range(1, vetor.size-1)])
            else:
                diferenca = np.array([])
            if(vetor.size > 1):
                diferenca = np.insert(diferenca, 0, (vetor[1] - vetor[0])*0.5)
                diferenca = np.append(diferenca, (vetor[-1] - vetor[-2])*0.5)
            else:
                diferenca = np.array([0])
            return diferenca
        
        _, _, colunas = self.distribuicoes.info_dataset()
        colunas = [col for col in colunas if col != self.__col_alvo]
        
        #Calcula um número que resume a tendência e a derivada dos gráficos de média para ver a tendência por valor da variável
        for col_ref in colunas:
            valores, labels, medias_alvo, tipo = self.__curva_medias_condicional(col_ref)
            self.__dict_impacto[col_ref] = np.std(medias_alvo) #np.max(medias_alvo) - np.min(medias_alvo)
            self.__dict_tendencia[col_ref] = calc_diff(medias_alvo)
        
        #Normaliza a derivada (o menor valor negativo será -1 e o maior positivo 1)
        minimos = np.array([])
        maximos = np.array([])
        for col_ref in colunas:
            tend = self.__dict_tendencia[col_ref]
            minimos = np.append(minimos, np.min(tend))
            maximos = np.append(maximos, np.max(tend))
        minimo = np.min(minimos)
        maximo = np.max(maximos)
        for col_ref in colunas:
            self.__dict_tendencia[col_ref] = np.array([v/maximo if v > 0 else v/np.abs(minimo) for v in self.__dict_tendencia[col_ref]])
        
        #Normaliza os impactos para que a soma seja 1
        valores = list(self.__dict_impacto.values())
        self.__dict_impacto = dict(zip(list(self.__dict_impacto.keys()), valores/np.sum(valores))) 
        
    def __curva_tendencia(self, col_ref):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
        medias_alvo = self.__dict_media_alvo[col_ref]
        tendencia = self.__dict_tendencia[col_ref]
        impacto = self.__dict_impacto[col_ref]
        
        #Ordena por média do alvo se forem categorias (e podemos rearranjar a ordem)
        if(tipo == 'categoria'):
            inds_ordenado = np.argsort(medias_alvo)
            valores = valores[inds_ordenado]
            labels = labels[inds_ordenado]
            medias_alvo = medias_alvo[inds_ordenado]
            
        return valores, labels, tipo, tendencia, impacto
                    
    def grafico_tendencias(self):      
        colunas = dict(reversed(sorted(self.__dict_impacto.items(), key = lambda x: x[1]))).keys()
        
        paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
        N = 256
        cor_neg = paleta_cores[0]
        cor_pos = paleta_cores[1]
        vals = np.ones((N, 4))
        regua = np.linspace(-1, 1, N)
        vals[:, 0] = np.array([cor_pos[0] if v > 0 else cor_neg[0] for v in regua])
        vals[:, 1] = np.array([cor_pos[1] if v > 0 else cor_neg[1] for v in regua])
        vals[:, 2] = np.array([cor_pos[2] if v > 0 else cor_neg[2] for v in regua])
        vals[:, 3] = np.array([(v**2)**(1/2) for v in regua]) #Aqui podemos alterar a velocidade com que o alpha muda
        cmap = mpl.colors.ListedColormap(vals)
        cores = cmap(np.arange(cmap.N))
        
        num_cols = len(colunas)
        fig, axs = plt.subplots(num_cols, 1, figsize = [7, 2*num_cols], constrained_layout = True)
        fig.suptitle('Tendência das Variáveis:')
        
        i = 0
        for col_ref in colunas:
            valores, labels, tipo, tendencia, impacto = self.__curva_tendencia(col_ref)
            cores_plot = cores[np.floor((tendencia + 1)*(N-1)/2).astype(int)]
            axs[i].imshow([cores_plot], aspect = 0.5*(valores.size/10), interpolation = 'spline16')
            axs[i].set_yticks([])
            
            if(labels is not None):
                if(tipo == 'intervalo'):
                    axs[i].set_xticks(valores)
                    axs[i].set_xticklabels(labels, rotation = 90)
                elif(tipo == 'categoria'):
                    axs[i].set_xticks(range(0, valores.size))
                    axs[i].set_xticklabels(labels)
            else:
                axs[i].set_xticks(range(0, valores.size))
                axs[i].set_xticklabels(valores.astype(str))

            axs[i].set_title(col_ref + ': ' + '%.2g' % impacto, loc = 'left')
            i = i + 1
        plt.show()
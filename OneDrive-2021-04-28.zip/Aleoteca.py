import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import OneHotEncoder

#TEM ALGUM BUG QUE FICA INTERVALO VAZIO E NÃO SEI AINDA QUANDO ACONTECE
#OBS: Tem que ser um tipo que possa ser convertido para float
#OBS: Não pode ter NA, mas pode ter -Inf e +Inf
class CortaIntervalosQuasiUniforme:

    def __init__(self, vetor, num_div):
        #OBS: Precisa estar em float o vetor para funcionar direito (se não ele força as contas a retornar inteiro)
        self.__vetor = vetor.astype(float) #vetor que queremos dividir em intervalos
        
        self.__qtd_tot = vetor.size #Tamanho do vetor que vamos discretizar
        self.__num_div = num_div #número de divisões que vamos tentar fazer
        
        self.__vetor_disc = None #Vetor discretizado
        self.__pontos_corte = None #Armazena os pontos de corte (min,max] obtidos na discretização por quantils
        
        self.__qtds = None #Quantidade de elementos por intervalo da discretização
        self.__min_ajust = None #Armazena a informacao de menor valor no intervalo ajustado
        self.__max_ajust = None #Armazena a informacao de maior valor no intervalo ajustado
        self.__qtds_por_compr = None #Quantidade de elementos por comprimento do intervalo (mede concentração)
        self.__densidade_valores = None #Fração de elementos do total do vetor por comprimento do intervalo (mede densidade)
        #OBS: Ajustado significa que ajustamos para que o final de um intervalo seja o início do outro (sem buracos) de forma simétrica
        
        self.__alga_signif = None #Armazena o melhor valor de algarismos significativos para diferenciar os intervalos
        self.__min_signif = None #Armazena a informacao de menor valor no intervalo com melhor alga_signif
        self.__max_signif = None #Armazena a informacao de maior valor no intervalo com melhor alga_signif
        #OBS: Vamos usar esses valores para criar as strings (a, b] que representa os intervalos
        
        self.__strings_intervalos = None #Strings sugeridas para identificar cada intervalo
        self.__pontos_medios = None #Pontos médios dos intervalos da discretização
        self.__pares_minimo_maximo = None #Vetor com os pares [min, max] de cada intervalo
        
        self.__calcula_intervalos()
        
    def __calcula_discretizacao(self):
        #Pega as divisões por quantis
        quantils = np.linspace(0, 100, self.__num_div + 1)
        valores_divisao = np.asarray(np.percentile(self.__vetor, quantils, interpolation = 'nearest'))
        
        #Encontra a primeira e última ocorrência de cada divisor de quantil
        valores_unicos, primeira_ocorrencia = np.unique(valores_divisao, return_index = True)
        valores_unicos, ultima_ocorrencia = np.unique(valores_divisao[::-1], return_index = True)
        ultima_ocorrencia = valores_divisao.size - 1 - ultima_ocorrencia
        
        #checa os divisores que aparecem mais de uma vez (significa que eles sozinhos já formam um Intervalo)
        flag_prim_igual_ult = (primeira_ocorrencia != ultima_ocorrencia).astype(int) + 1
        #Cria os intervalos considerando os intervalos que podem conter só um valor
        valores_divisao = np.array([valores_unicos[i] for i in range(valores_unicos.size) for j in range(flag_prim_igual_ult[i])])
        
        vetor_unicos = np.unique(self.__vetor) #Pega os valores únicos do vetor que estamos discretizando
        diff_zero = np.append(np.diff(valores_divisao) == 0, False) #Flag com as posições em que o próximo elemento é igual ao atual (intervalos com um só valor)
        
        #Simetriza os intervalos colocando o corte no meio do "vácuo de valores"
        flag_simetrizar = np.append(np.insert(~diff_zero[1:-1], 0, False), False) #Não tem pq fazer isso nas pontas (nem no inicio de um intervalo de um só valor)
        #Encontramos o valor superior ao corte por busca binária
        valores_sup = np.array([])
        vetor_unicos_aux = vetor_unicos.copy()
        for valor in valores_divisao[flag_simetrizar]:
            ind_sup = np.searchsorted(vetor_unicos_aux, valor) + 1
            valores_sup = np.append(valores_sup, vetor_unicos_aux[ind_sup])
            vetor_unicos_aux = vetor_unicos_aux[ind_sup:] #Já descartamos os valores do vetor que não tem mais pq buscar
        valores_divisao[flag_simetrizar] = (valores_divisao[flag_simetrizar] + valores_sup)/2 #Ajustamos o corte para o meio dos dois valores
        
        #Precisamos encontrar os intervalos com só um valor e simetrizar o inicio (que antes foi desconsiderado na simetrização)
        flag_simetrizar = np.append(np.insert(diff_zero[1:-1], 0, False), False) #Novamente, não tem necessidade de fazer isso nas pontas
        #Encontramos o valor inferior ao corte por busca binária
        valores_inf = np.array([])
        vetor_unicos_aux = vetor_unicos.copy()
        for valor in valores_divisao[flag_simetrizar]:
            ind_inf = np.searchsorted(vetor_unicos_aux, valor) - 1
            valores_inf = np.append(valores_inf, vetor_unicos_aux[ind_inf])
            vetor_unicos_aux = vetor_unicos_aux[ind_inf:] #Já descartamos os valores do vetor que não tem mais pq buscar
        valores_divisao[flag_simetrizar] = (valores_inf + valores_divisao[flag_simetrizar])/2 #Ajustamos o corte para o meio dos dois valores
        
        #Remove valores de corte repetidos caso tenha aparecido algum após a simetrização
        if(valores_divisao.size > 2): #Só é necessário se tivermos mais de um intervalo: para não dar problema se só tiver um intervalo (0, 0], por exemplo
            valores_divisao = np.unique(valores_divisao) 
            
        self.__pontos_corte = valores_divisao #Guarda os pontos de corte
        self.__vetor_disc = np.digitize(self.__vetor, self.__pontos_corte[1:], right = True) #Faz a discretização pelos pontos de corte
    
    def __calcula_info_discretizacao(self):
        #Calcula as informações da discretização feita
        #1)Quantidade de elementos em cada intervalo
        #2)Os valores de mínimo e máximo do começo e final de cada intervalo
        #3)Densidade/Concentração de valores em cada intervalo
        
        ind_unico, qtds = np.unique(self.__vetor_disc, return_counts = True)
        self.__qtds = np.zeros(self.__pontos_corte.size - 1)
        self.__qtds[ind_unico] = qtds
        
        self.__min_ajust = self.__pontos_corte[:-1]
        self.__max_ajust = self.__pontos_corte[1:]
        
        L = self.__max_ajust - self.__min_ajust
        self.__qtds_por_compr = np.zeros(self.__pontos_corte.size - 1)
        flag_L0_Inf = (L == 0)&(self.__qtds > 0)
        flag_L0_Zero = (L == 0)&(self.__qtds == 0)
        flag_resto = (~flag_L0_Inf)&(~flag_L0_Zero)
        self.__qtds_por_compr[flag_L0_Inf] = np.inf
        self.__qtds_por_compr[flag_L0_Zero] = 0
        self.__qtds_por_compr[flag_resto] = self.__qtds[flag_resto]/L[flag_resto]
        self.__densidade_valores = self.__qtds_por_compr/self.__qtd_tot
        
    def __calcula_melhor_alga_signif(self):
        #Calcula o melhor algarismo significativo para utilizar na string (a,b] do intervalo
        #Defiminos o melhor algarismo significativo como o menor valor que consegue expressar todas as separações
        
        #Se os intervalos forem todos distintos
        if(np.sum(np.diff(self.__pontos_corte)) > 0):
            alga_signif = 1
            str_conv = '%.' + str(alga_signif) + 'g'
            cortes_interv = np.array([float(str_conv%self.__pontos_corte[i]) for i in range(self.__pontos_corte.size)])
            if(cortes_interv.size > 1): #Se houver mais de um corte de intervalos (ou seja, mais de 2 intervalos)
                flag = np.min(np.diff(cortes_interv)) #A diferença entre os pontos de corte não pode dar zero (não pode ter pontos de corte iguais)
                while flag == 0:
                    alga_signif += 1
                    str_conv = '%.' + str(alga_signif) + 'g'
                    cortes_interv = np.array([float(str_conv%self.__pontos_corte[i]) for i in range(self.__pontos_corte.size)])
                    flag = np.min(np.diff(cortes_interv))
        #Exemplo: self.__pontos_corte = [1.5, 1.5] -> só tem um intervalo e todos os elementos tem o mesmo valor
        else:
            alga_signif = 1
            str_conv = '%.' + str(alga_signif) + 'g'
            cortes_interv = np.array([float(str_conv%self.__pontos_corte[i]) for i in range(self.__pontos_corte.size)])
        
        self.__alga_signif = alga_signif
        self.__min_signif = cortes_interv[:-1]
        self.__max_signif = cortes_interv[1:]
    
    def __calcula_strings_intervalos(self):
        min_str = [str(v) for v in self.__min_signif]
        max_str = [str(v) for v in self.__max_signif]
        min_str = [v if v[-2:] != '.0' else v[:-2] for v in min_str]
        max_str = [v if v[-2:] != '.0' else v[:-2] for v in max_str]
        self.__strings_intervalos = np.array(['('+min_str[i]+', '+max_str[i]+']' for i in range(self.__qtds.size)])
    
    def __calcula_intervalos(self):
        self.__calcula_discretizacao()
        self.__calcula_info_discretizacao()
        self.__calcula_melhor_alga_signif()
        self.__calcula_strings_intervalos()
        self.__pontos_medios = (self.__min_ajust + self.__max_ajust)/2
        self.__pares_minimo_maximo = np.array(list(zip(self.__min_ajust, self.__max_ajust)))
    
    def vetor_discretizado(self, usar_ponto_medio = False):
        if(usar_ponto_medio):
            return self.__pontos_medios[self.__vetor_disc]
        else:
            return self.__vetor_disc
    
    def pares_minimo_maximo_discretizacao(self):
        return self.__pares_minimo_maximo

    def pontos_medios_discretizacao(self):
        return self.__pontos_medios

    def strings_intervalos_discretizacao(self):
        return self.__strings_intervalos
    
    def info_discretizacao(self):
        #Retorna um dataframe com as informações relevantes de cada intervalo da discretização
        df = pd.DataFrame(zip(self.__qtds, self.__densidade_valores, self.__min_ajust, self.__max_ajust, self.__strings_intervalos), 
                          columns = ['QTD', 'Frac/L', 'Min', 'Max', 'Str'])
        return df
    
    def curva_distribuicao(self):
        valores = np.array([x for y in self.__pares_minimo_maximo for x in y])
        fracL = np.repeat(self.__densidade_valores, 2)
        return valores, fracL
    
    def grafico_distribuicao(self, figsize = [6, 4]):
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            valores, fracL = self.curva_distribuicao()
            axs.fill_between(valores, fracL, color = paleta_cores[0], alpha = 0.5)
            axs.plot(valores, fracL, color = paleta_cores[0])
            axs.set_xlabel('Valores')
            axs.set_ylabel('Fração/L')
            axs.set_ylim(bottom = 0.0)
            plt.show()
    
    def aplica_discretizacao(self, v, usar_ponto_medio = False):
        if(usar_ponto_medio):
            disc = np.digitize(v, self.__pontos_corte[1:], right = True)
            def pega_elemento_vetor(vetor, i):
                try:
                    return vetor[i]
                except:
                    return np.nan
            return np.array([pega_elemento_vetor(self.__pontos_medios, i) for i in disc])
        else:
            disc = np.digitize(v, self.__pontos_corte[1:], right = True)
            flag_na = disc == self.__qtds.size
            if(np.sum(flag_na) > 0):
                disc = disc.astype(float)
                disc[flag_na] = np.nan
            return disc

########################
 
########################
 
#OBS: Tem que ser um tipo que possa ser convertido para string
#OBS: Não pode ter NA
class FiltraCategoriasRelevantes:
 
    def __init__(self, vetor, frac_cat):
        self.__vetor = vetor.astype(str) #vetor que queremos filtrar as categorias
        
        self.__qtd_tot = vetor.size #Tamanho do vetor que vamos filtrar
        self.__frac_cat = frac_cat #fração mínima da categoria no vetor para ser considerada relevante
        
        self.__vetor_filtrado = None #Vetor filtrado
        self.__dict_cat = None #Dicionário para aplicação do filtro
        self.__vetor_cat = None #Vetor para aplicação do filtro
        
        self.__cats = None #Lista de todas as categorias encontradas (ordenado por quantidade na base)
        self.__qtds = None #Quantidade de elementos por categoria
        self.__frac_cats = None #Fração de cada categoria no vetor
        self.__flag_rel = None #Marca se a categoria foi considerada relevante ou não
        
        self.__cats_rel = None #Vetor com as categorias relevantes (em ordem de relevância)
        self.__cats_rest = None #Vetor com todas as categorias que foram separadas como "restante" (última categoria)
        self.__num_cats_rel = None #Número de categorias relevantes
        self.__num_cats_rest = None #Número de categorias relevantes
        
        self.__calcula_categorias_relevantes()
    
    def __calcula_quantidade_categorias(self):
        self.__cats, self.__qtds = np.unique(self.__vetor, return_counts = True)
        inds_ordenado = np.argsort(self.__qtds)[::-1]
        self.__cats = self.__cats[inds_ordenado]
        self.__qtds = self.__qtds[inds_ordenado]
        self.__frac_cats = self.__qtds/self.__qtd_tot
        
    def __filtra_categorias_relevantes(self):
        self.__flag_rel = self.__frac_cats >= self.__frac_cat
        self.__cats_rel = self.__cats[self.__flag_rel]
        self.__cats_rest = self.__cats[~self.__flag_rel]
        self.__num_cats_rel = self.__cats_rel.size
        self.__num_cats_rest = self.__cats_rest.size
    
    def __cria_dicionario_aplicacao(self):
        dict_cats = dict(zip(self.__cats_rel, np.arange(0, self.__num_cats_rel)))
        if(self.__num_cats_rest > 0):
            dict_cat_rest = dict(zip(self.__cats_rest, np.repeat(self.__num_cats_rel, self.__num_cats_rest)))
            dict_cats.update(dict_cat_rest)
        self.__dict_cat = dict_cats
        
    def __cria_vetor_aplicacao_str(self):
        if(self.__num_cats_rest > 1):
            vetor_cats = np.append(self.__cats_rel, 'Resto')
        elif(self.__num_cats_rest == 1):
            vetor_cats = np.append(self.__cats_rel, self.__cats_rest)
        else:
            vetor_cats = self.__cats_rel
        self.__vetor_cat = vetor_cats
    
    def __calcula_categorias_relevantes(self):
        self.__calcula_quantidade_categorias()
        self.__filtra_categorias_relevantes()
        self.__cria_dicionario_aplicacao()
        self.__cria_vetor_aplicacao_str()
    
    def strings_categorias(self):
        return self.__vetor_cat
    
    def info_categorias(self):
        if(self.__num_cats_rest > 0):
            qtds_filtro = np.append(self.__qtds[self.__flag_rel], np.sum(self.__qtds[~self.__flag_rel]))
            frac_filtro = qtds_filtro/self.__qtd_tot
            flag_resto = np.append(np.repeat(False, self.__num_cats_rel), True)
            categorias_filtro = np.append(self.__cats_rel, ', '.join(self.__cats_rest))
            df = pd.DataFrame(zip(qtds_filtro, frac_filtro, flag_resto, categorias_filtro), 
                              columns = ['QTD', 'Fração', 'Flag_Resto', 'Categoria'])
        else:
            flag_resto = np.repeat(False, self.__num_cats_rel)
            df = pd.DataFrame(zip(self.__qtds, self.__frac_cats, flag_resto, self.__cats), 
                              columns = ['QTD', 'Fração', 'Flag_Resto', 'Categoria'])
        return df
    
    def curva_distribuicao(self):
        valores = self.__vetor_cat
        frac = self.__frac_cats[self.__flag_rel]
        if(self.__num_cats_rest > 0):
            frac = np.append(frac, 1-np.sum(frac))
        return valores, frac
    
    def grafico_distribuicao(self, figsize = [6, 4]):
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            valores, frac = self.curva_distribuicao()
            axs.bar(valores, frac, color = paleta_cores[0], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[0])
            axs.set_xlabel('Valores')
            axs.set_ylabel('Fração')
            axs.set_ylim(bottom = 0.0)
            plt.show()
    
    def aplica_filtro_categorias(self, vetor, considera_resto = True, usar_str = False):
        def pega_valor_dicionario(dicionario, v):
            try:
                return dicionario[v]
            except:
                return np.nan
        vetor_filtrado = np.array([pega_valor_dicionario(self.__dict_cat, v) for v in vetor])
        if(considera_resto == False):
            if(self.__num_cats_rest > 0):
                vetor_filtrado = vetor_filtrado.astype(float)
                vetor_filtrado[vetor_filtrado == self.__num_cats_rel] = np.nan
        if(usar_str):
            def pega_elemento_vetor(vetor, i):
                try:
                    return vetor[int(i)]
                except:
                    return np.nan
            vetor_filtrado = [pega_elemento_vetor(self.__vetor_cat, i) for i in vetor_filtrado]
            #vetor_filtrado = np.array([pega_elemento_vetor(self.__vetor_cat, i) for i in vetor_filtrado], dtype = str) #Problema com os NaN
        return vetor_filtrado
  
 ########################
 
 ########################

class TrataDataset:
 
    def __init__(self, df, num_div = 20, frac_cat = 0.05, features_numericas = None, features_categoricas = None):
        self.__df = df
        self.__num_div = num_div
        self.__frac_cat = frac_cat
        self.__features_numericas = features_numericas
        self.__features_categoricas = features_categoricas
        self.__features_numericas_tratadas = np.array([])
        
        self.__dict_intervs = {}
        self.__dict_filtroscat = {}
        
        if(isinstance(self.__features_numericas, list) and self.__num_div != None):
            for feature in self.__features_numericas:
                if(np.unique(df[feature].dropna().values).size > self.__num_div):
                    self.__dict_intervs[feature] = CortaIntervalosQuasiUniforme(df[feature].dropna().values, num_div = self.__num_div)
                    self.__features_numericas_tratadas = np.append(self.__features_numericas_tratadas, feature)
                
        if(isinstance(self.__features_categoricas, list) and self.__frac_cat != None):
            for feature in self.__features_categoricas:
                self.__dict_filtroscat[feature] = FiltraCategoriasRelevantes(df[feature].dropna().values, frac_cat = self.__frac_cat)
        
        self.__encoder = None
        self.__considera_resto_ohe = None
        self.__usar_str_ohe = None
        
    def retorna_instancias_tratamento(self):
        return self.__dict_intervs, self.__dict_filtroscat
        
    def cria_one_hot_encoder(self, considera_resto = True, usar_str = False):
        if(isinstance(self.__features_categoricas, list)):
            if(self.__frac_cat != None):
                lista_cats = []
                for feature in self.__features_categoricas:
                    transf = self.__dict_filtroscat[feature].aplica_filtro_categorias(self.__df[feature].values, considera_resto = considera_resto, usar_str = usar_str)
                    lista_cats.append(transf)
                df_cat = pd.DataFrame(zip(*lista_cats), columns = self.__features_categoricas, index = self.__df.index)
            else:
                df_cat = self.__df[self.__features_categoricas]
            valores = df_cat.values
            if(usar_str):
                flag_na = pd.isna(df_cat).values
                valores[flag_na] = '-1'
            else:
                flag_na = np.isnan(valores, where = True)
                valores[flag_na] = -1
                valores = valores.astype(int)
            self.__encoder = OneHotEncoder(handle_unknown = 'ignore', sparse = False).fit(valores)
            self.__considera_resto_ohe = considera_resto
            self.__usar_str_ohe = usar_str
    
    def aplica_transformacao(self, df_inp, usar_ponto_medio = False, considera_resto = True, usar_str = False):
        df_aplic = df_inp.copy()
        if(isinstance(self.__features_numericas, list) and self.__num_div != None):
            for feature in self.__features_numericas_tratadas:
                df_aplic[feature] = self.__dict_intervs[feature].aplica_discretizacao(df_aplic[feature].values, usar_ponto_medio = usar_ponto_medio)
                 
        if(isinstance(self.__features_categoricas, list) and self.__frac_cat != None):
            for feature in self.__features_categoricas:
                df_aplic[feature] = self.__dict_filtroscat[feature].aplica_filtro_categorias(df_aplic[feature].values, 
                                                                                           considera_resto = considera_resto, usar_str = usar_str)
                                                                                           
        return df_aplic
        
    def aplica_transformacao_ohe(self, df_inp, usar_ponto_medio = False):
        df_aplic = df_inp.copy()
        df_aplic = self.aplica_transformacao(df_inp, usar_ponto_medio = usar_ponto_medio, 
                                             considera_resto = self.__considera_resto_ohe, usar_str = self.__usar_str_ohe)
                                             
        if(isinstance(self.__features_categoricas, list)):
            valores = df_aplic[self.__features_categoricas].values
            if(self.__usar_str_ohe):
                flag_na = pd.isna(df_aplic[self.__features_categoricas]).values
                valores[flag_na] = '-1'
            else:
                flag_na = np.isnan(valores, where = True)
                valores[flag_na] = -1
                valores = valores.astype(int)
            matriz_cat = self.__encoder.transform(valores)
            nome_colunas = self.__encoder.get_feature_names(self.__features_categoricas)
            df_cat = pd.DataFrame(matriz_cat, columns = nome_colunas, index = df_aplic.index)
            df_cat = df_cat.drop([col for col in nome_colunas if col[-3:] == '_-1'], axis = 1).astype(int)
            df_aplic = df_aplic.drop(self.__features_categoricas, axis = 1)
            df_aplic = pd.concat([df_aplic, df_cat], axis = 1)
            
        return df_aplic
        
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D

from AleTransforms import *

#Para funcionar direito, é preciso transformar os valores numéricos todos em float (não pode ter int, por exemplo)
class DistribuicoesDataset:

    def __init__(self, df, num_div = None, frac_cat = 0):
        self.__df = df
        self.__num_linhas = len(self.__df)
        self.__colunas = df.columns.values
        self.__num_colunas = self.__colunas.size
        
        self.__num_div = num_div
        self.__frac_cat = frac_cat
        
        self.__dict_flag_na = {}
        self.__dict_frac_na = {}
        self.__tipo_numerico = np.array([])
        self.__tipo_categorico = np.array([])
        
        for col in self.__colunas:
            self.__encontra_na(col)
        
        self.__tratadf = TrataDataset(self.__df, num_div = self.__num_div, frac_cat = self.__frac_cat, 
                                      features_numericas = list(self.__tipo_numerico), features_categoricas = list(self.__tipo_categorico))        
        self.__dict_intervs, self.__dict_filtroscat = self.__tratadf.retorna_instancias_tratamento()
    
    def info_dataset(self):
        return self.__num_linhas, self.__num_colunas, self.__colunas
        
    def retorna_trata_dataset(self):
        return self.__tratadf
    
    def retorna_flag_na(self, col_ref):
        return self.__dict_flag_na[col_ref]
    
    #Enquantra a quantidade e posições dos NA na coluna e separa as colunas por tipo
    def __encontra_na(self, col_ref):
        valores = self.__df[col_ref].values
        if(valores.dtype in [np.number, 'int64', 'float64']):
            flag_na = np.isnan(valores, where = True)
            self.__tipo_numerico = np.append(self.__tipo_numerico, col_ref)
        else:
            flag_na = pd.isna(self.__df[col_ref]).values
            self.__tipo_categorico = np.append(self.__tipo_categorico, col_ref)
        self.__dict_flag_na[col_ref] = flag_na
        self.__dict_frac_na[col_ref] = np.sum(flag_na)/self.__num_linhas
    
    def curva_distribuicao(self, col_ref):
        if(col_ref in self.__colunas):
            if(col_ref in self.__dict_intervs.keys()):
                valores, frac = self.__dict_intervs[col_ref].curva_distribuicao()
                tipo = 'intervalo'
                
            elif(col_ref in self.__dict_filtroscat.keys()):
                valores, frac = self.__dict_filtroscat[col_ref].curva_distribuicao()
                tipo = 'categoria'
            else:
                valores, qtds = np.unique(self.__df[col_ref].dropna().values, return_counts = True)
                frac = qtds/self.__num_linhas
                tipo = 'discreto'
            return valores, frac, tipo
    
    def grafico_distribuicao(self, col_ref = [], conv_str = True, figsize = [6, 4]):
        #Transforma uma string única em uma lista
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
        #Se não passar nada plota o gráfico de todas as colunas
        if(len(col_ref) == 0):
            colunas = self.__colunas
        else:
            colunas = col_ref
        
        #Para cada coluna
        for col_ref in colunas:
            if(col_ref in self.__colunas):
                paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
                
                frac_na = self.__dict_frac_na[col_ref]
                
                #Plota informações da distribuição da variável de referência nos dados
                with sns.axes_style("whitegrid"):
                    fig, axs = plt.subplots(1, 1, figsize = figsize)
                    valores, frac, tipo = self.curva_distribuicao(col_ref)
                    if(tipo == 'intervalo'):
                        axs.fill_between(valores, frac, color = paleta_cores[0], alpha = 0.5)
                        axs.plot(valores, frac, color = paleta_cores[0])
                        axs.set_ylabel('Fração/L')
                    elif(tipo == 'categoria'):
                        axs.bar(valores, frac, color = paleta_cores[0], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[0])
                        axs.set_ylabel('Fração')
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        axs.bar(valores, frac, color = paleta_cores[0], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[0])
                        axs.set_ylabel('Fração')
                    plt.gcf().text(1, 0.8, 'Fração de NA = ' + '%.2g' % frac_na, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                    axs.set_xlabel(col_ref)
                    axs.set_ylim(bottom = 0.0)
                    plt.show()
                    
##############################

##############################

class TendenciasAlvoDataset:

    def __init__(self, df, col_alvo, num_div = None, frac_cat = 0):
        
        self.distribuicoes = DistribuicoesDataset(df, num_div, frac_cat)
        self.__dict_intervs, self.__dict_filtroscat = self.distribuicoes.retorna_trata_dataset().retorna_instancias_tratamento()
        self.__df_tratado = self.distribuicoes.retorna_trata_dataset().aplica_transformacao(df, usar_ponto_medio = False, considera_resto = True, usar_str = False)
        
        self.__y = df[col_alvo].values
        self.__col_alvo = col_alvo
        
        self.__dict_valores = {}
        self.__dict_qtds = {}
        
        self.__dict_soma_alvo = {}
        self.__dict_media_alvo = {}
        
        self.__dict_tendencia = {}
        self.__dict_impacto = {}
        
        self.__calcula_metricas_condicionais()
        self.__calcula_tendencias()
    
    def __calcula_metricas_condicionais(self):
        _, _, colunas = self.distribuicoes.info_dataset()
        for col_ref in colunas:
            flag_na = self.distribuicoes.retorna_flag_na(col_ref)
            valores = self.__df_tratado.loc[~flag_na, col_ref].astype(int).values
            y = self.__y[~flag_na]
            
            inds_ordenado = np.argsort(valores)
            valores_unico, primeira_ocorrencia, qtds = np.unique(valores[inds_ordenado], return_index = True, return_counts = True)
            self.__dict_valores[col_ref] = valores_unico
            self.__dict_qtds[col_ref] = qtds
            
            y_agrup = np.split(y[inds_ordenado], primeira_ocorrencia[1:])
            soma_alvo = np.array([np.sum(v) for v in y_agrup])
            self.__dict_soma_alvo[col_ref] = soma_alvo
            self.__dict_media_alvo[col_ref] = soma_alvo/qtds

    def valor_metricas_condicionais(self, col_ref):
        _, _, colunas = self.distribuicoes.info_dataset()
        df = pd.DataFrame()
        if(col_ref in colunas):
            df['Valores'] = self.__dict_valores[col_ref]
            if(col_ref in self.__dict_intervs.keys()):
                df['Labels'] = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            elif(col_ref in self.__dict_filtroscat.keys()):
                df['Labels'] = self.__dict_filtroscat[col_ref].strings_categorias()
            df['QTD'] = self.__dict_qtds[col_ref]
            df['Soma_Alvo'] = self.__dict_soma_alvo[col_ref]
            df['Media_Alvo'] = self.__dict_media_alvo[col_ref]       
        return df
    
    def __curva_medias_condicional(self, col_ref):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
        medias_alvo = self.__dict_media_alvo[col_ref]
        
        #Ordena por média do alvo se forem categorias (e podemos rearranjar a ordem)
        if(tipo == 'categoria'):
            inds_ordenado = np.argsort(medias_alvo)
            valores = valores[inds_ordenado]
            labels = labels[inds_ordenado]
            medias_alvo = medias_alvo[inds_ordenado]
        
        return valores, labels, medias_alvo, tipo
    
    def grafico_medias_condicional(self, col_ref = [], conv_str = True, figsize = [6, 4]):
        _, _, colunas = self.distribuicoes.info_dataset()
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
        if(len(col_ref) != 0):
            colunas = col_ref
            
        for col_ref in colunas:
            if(col_ref in colunas):
                paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
                
                with sns.axes_style("whitegrid"):
                    fig, axs = plt.subplots(1, 1, figsize = figsize)
                    valores, labels, medias_alvo, tipo = self.__curva_medias_condicional(col_ref)
                    if(labels is not None):
                        if(tipo == 'intervalo'):
                            axs.bar(valores, medias_alvo, color = paleta_cores[0])
                            axs.set_xticks(valores)
                            axs.set_xticklabels(labels, rotation = 90)
                        elif(tipo == 'categoria'):
                            axs.bar(labels, medias_alvo, color = paleta_cores[0])
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        axs.bar(valores, medias_alvo, color = paleta_cores[0])
                    axs.set_xlabel(col_ref)
                    axs.set_ylabel('Média Alvo')
                    plt.show()
    
    def __calcula_tendencias(self):
    
        #Calculamos a derivada por aproximação de uma parábola (com os 2 pontos mais próximos)
        def calc_diff(vetor):
            if(vetor.size > 2):
                diferenca = np.array([(vetor[i+1] - vetor[i-1])*0.5 for i in range(1, vetor.size-1)])
            else:
                diferenca = np.array([])
            if(vetor.size > 1):
                diferenca = np.insert(diferenca, 0, (vetor[1] - vetor[0])*0.5)
                diferenca = np.append(diferenca, (vetor[-1] - vetor[-2])*0.5)
            else:
                diferenca = np.array([0])
            return diferenca
        
        _, _, colunas = self.distribuicoes.info_dataset()
        colunas = [col for col in colunas if col != self.__col_alvo]
        
        #Calcula um número que resume a tendência e a derivada dos gráficos de média para ver a tendência por valor da variável
        for col_ref in colunas:
            valores, labels, medias_alvo, tipo = self.__curva_medias_condicional(col_ref)
            self.__dict_impacto[col_ref] = np.std(medias_alvo) #np.max(medias_alvo) - np.min(medias_alvo)
            self.__dict_tendencia[col_ref] = calc_diff(medias_alvo)
        
        #Normaliza a derivada (o menor valor negativo será -1 e o maior positivo 1)
        minimos = np.array([])
        maximos = np.array([])
        for col_ref in colunas:
            tend = self.__dict_tendencia[col_ref]
            minimos = np.append(minimos, np.min(tend))
            maximos = np.append(maximos, np.max(tend))
        minimo = np.min(minimos)
        maximo = np.max(maximos)
        for col_ref in colunas:
            self.__dict_tendencia[col_ref] = np.array([v/maximo if v > 0 else v/np.abs(minimo) for v in self.__dict_tendencia[col_ref]])
        
        #Normaliza os impactos para que a soma seja 1
        valores = list(self.__dict_impacto.values())
        self.__dict_impacto = dict(zip(list(self.__dict_impacto.keys()), valores/np.sum(valores))) 
        
    def __curva_tendencia(self, col_ref):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
        medias_alvo = self.__dict_media_alvo[col_ref]
        tendencia = self.__dict_tendencia[col_ref]
        impacto = self.__dict_impacto[col_ref]
        
        #Ordena por média do alvo se forem categorias (e podemos rearranjar a ordem)
        if(tipo == 'categoria'):
            inds_ordenado = np.argsort(medias_alvo)
            valores = valores[inds_ordenado]
            labels = labels[inds_ordenado]
            medias_alvo = medias_alvo[inds_ordenado]
            
        return valores, labels, tipo, tendencia, impacto
                    
    def grafico_tendencias(self):      
        colunas = dict(reversed(sorted(self.__dict_impacto.items(), key = lambda x: x[1]))).keys()
        
        paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
        N = 256
        cor_neg = paleta_cores[0]
        cor_pos = paleta_cores[1]
        vals = np.ones((N, 4))
        regua = np.linspace(-1, 1, N)
        vals[:, 0] = np.array([cor_pos[0] if v > 0 else cor_neg[0] for v in regua])
        vals[:, 1] = np.array([cor_pos[1] if v > 0 else cor_neg[1] for v in regua])
        vals[:, 2] = np.array([cor_pos[2] if v > 0 else cor_neg[2] for v in regua])
        vals[:, 3] = np.array([(v**2)**(1/2) for v in regua]) #Aqui podemos alterar a velocidade com que o alpha muda
        cmap = mpl.colors.ListedColormap(vals)
        cores = cmap(np.arange(cmap.N))
        
        num_cols = len(colunas)
        fig, axs = plt.subplots(num_cols, 1, figsize = [7, 2*num_cols], constrained_layout = True)
        fig.suptitle('Tendência das Variáveis:')
        
        i = 0
        for col_ref in colunas:
            valores, labels, tipo, tendencia, impacto = self.__curva_tendencia(col_ref)
            cores_plot = cores[np.floor((tendencia + 1)*(N-1)/2).astype(int)]
            axs[i].imshow([cores_plot], aspect = 0.5*(valores.size/10), interpolation = 'spline16')
            axs[i].set_yticks([])
            
            if(labels is not None):
                if(tipo == 'intervalo'):
                    axs[i].set_xticks(valores)
                    axs[i].set_xticklabels(labels, rotation = 90)
                elif(tipo == 'categoria'):
                    axs[i].set_xticks(range(0, valores.size))
                    axs[i].set_xticklabels(labels)
            else:
                axs[i].set_xticks(range(0, valores.size))
                axs[i].set_xticklabels(valores.astype(str))

            axs[i].set_title(col_ref + ': ' + '%.2g' % impacto, loc = 'left')
            i = i + 1
        plt.show()
        
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D

from AleTransforms import *

#Para funcionar direito, não pode haver nulos em y ou y_prob
class AletricasClassificacao:
    
    def __init__(self, y, y_prob, num_div = None, p_corte = None, p01_corte = [0, 0]):
        self.__y = y
        self.__y_prob = y_prob
        self.__y_prob_inicial = y_prob
        
        #Probabilidades de Corte para Avaliação de Tomada de Decisão
        #OBS: Quando nenhuma prob de corte é passada, 
        #usamos a prob de ganho de informação para a tomada de decisão
        self.__p_corte = p_corte
        self.__p01_corte = np.array(p01_corte)
        
        #Variaveis caso queira fazer as contas por intervalos de prob
        self.__num_div = num_div
        self.__interv = None
        
        self.__qtd_tot = None
        self.__soma_probs = None
        self.__qtd1_tot = None
        self.__qtd0_tot = None
        
        self.__y_prob_unico = None
        self.__qtds = None
        self.__qtds1 = None
        
        self.__qtds_acum = None
        self.__qtds1_acum = None
        self.__qtds0_acum = None
        
        #_c indica o conjunto complementar (o que ainda não foi somado)
        self.__qtds_acum_c = None
        self.__qtds1_acum_c = None 
        self.__qtds0_acum_c = None 
        
        #vp: verdadeiro positivo, p_tot: total de positivos
        #vn: verdadeiro negativo, n_tot: total de negativos
        self.__curva_tvp = None #Armazena a curva de taxa de verdadeiro positivo (vp / p_tot)
        self.__curva_tvn = None #Armazena a curva de taxa verdadeiro negativo (vn / n_tot)
        self.__auc = None
        
        self.__curva_revoc1 = None #Armazena a curva de revocacao de 1
        self.__curva_revoc0 = None #Armazena a curva de revocacao de 0
        self.__pos_max_dif = None
        self.__ks = None
        
        self.__curva_ig = None #Armazena a curva de ganho de informação
        self.__pos_max_ig = None
        self.__ig = None
        
        self.__liftF_10 = None
        self.__alavF_10 = None
        self.__liftF_20 = None
        self.__alavF_20 = None
        self.__liftV_10 = None
        self.__alavV_10 = None
        self.__liftV_20 = None
        self.__alavV_20 = None
        
        self.__vetor_p0_ig_2d = None
        self.__vetor_p1_ig_2d = None
        self.__vetor_ig_2d = None
        self.__pos_max_ig_2d = None
        self.__ig_2d = None
        
        self.matriz_confusao = None
        self.matriz_confusao_2d = None
        self.__frac_incerto_2d = None
        self.__p00 = None #Prob de ser 0 dado que o modelo disse que é 0
        self.__p11 = None #Prob de ser 1 dado que o modelo disse que é 1
        self.__p00_2d = None #Prob de ser 0 dado que o modelo disse que é 0 (corte com p0 e p1)
        self.__p11_2d = None #Prob de ser 1 dado que o modelo disse que é 1 (corte com p0 e p1)
        self.__acuracia = None
        self.__acuracia_balanceada = None
        self.__acuracia_2d = None 
        self.__acuracia_balanceada_2d = None
        
        self.__calcula_metricas()
        
    def __ordena_probs(self):
        self.__qtd_tot = self.__y.size
        self.__soma_probs = np.sum(self.__y_prob)
        
        if(self.__num_div != None):
            self.__interv = CortaIntervalosQuasiUniforme(self.__y_prob, num_div = self.__num_div)
            self.__y_prob = self.__interv.vetor_discretizado()
        
        inds_ordenado = np.argsort(self.__y_prob)
        self.__y_prob_unico, primeira_ocorrencia, self.__qtds = np.unique(self.__y_prob[inds_ordenado], 
                                                                      return_index = True, return_counts = True)
        y_agrup = np.split(self.__y[inds_ordenado], primeira_ocorrencia[1:])
        self.__qtds1 = np.array([np.sum(v) for v in y_agrup])
        
        self.__qtds_acum = np.cumsum(self.__qtds) 
        self.__qtds1_acum = np.cumsum(self.__qtds1)
        self.__qtds0_acum = self.__qtds_acum - self.__qtds1_acum
        
        self.__qtd1_tot = self.__qtds1_acum[-1]
        self.__qtd0_tot = self.__qtd_tot - self.__qtd1_tot
        
        self.__qtds_acum_c = self.__qtd_tot - self.__qtds_acum
        self.__qtds1_acum_c = self.__qtd1_tot - self.__qtds1_acum
        self.__qtds0_acum_c = self.__qtd0_tot - self.__qtds0_acum
    
    def __calcula_roc(self):
        #Estima a área abaixo da curva por Soma de Riemann
        def area(x,y):
            dx = np.diff(x)
            h = (y[:-1] + y[1:])/2
            A = np.sum(h*dx)
            return A
        
        self.__curva_tnp = self.__qtds0_acum/self.__qtd0_tot
        self.__curva_tvp = self.__qtds1_acum_c/self.__qtd1_tot
        
        #Coloca na mão o valor inicial da curva ROC
        self.__curva_tnp = np.insert(self.__curva_tnp, 0, 0)
        self.__curva_tvp = np.insert(self.__curva_tvp, 0, 1)
            
        self.__auc = area(self.__curva_tnp, self.__curva_tvp)
    
    def __calcula_ks(self):
        self.__curva_revoc0 = self.__qtds0_acum/self.__qtd0_tot
        self.__curva_revoc1 = self.__qtds1_acum/self.__qtd1_tot
        
        curva_dif = self.__curva_revoc0 - self.__curva_revoc1
        self.__pos_max_dif = np.argmax(curva_dif) #Pega as posições em que encontrou o máximo
        
        #Pega o valor máximo (tenta ver se pos_max é um vetor ou um número)
        try:
            self.__ks = curva_dif[self.__pos_max_dif[0]]
        except:
            self.__ks = curva_dif[self.__pos_max_dif]
        #OBS: 
        #self.__ks = np.max(curva_dif[self.__pos_max_dif]) seria mais genérico mas o try nesse caso é mais rápido
    
    def __calcula_lift_alavancagem(self, decrescente = False, frac = 0.5):
        qtd_ref = frac*self.__qtd_tot
        if(decrescente == False):
            pos_ini = np.sum(self.__qtds_acum <= qtd_ref) - 1
            if(self.__qtds_acum[pos_ini] == qtd_ref or pos_ini == self.__qtds_acum.size - 1):
                lift = self.__qtds0_acum[pos_ini]/qtd_ref
                alav = lift/frac
            else:
                qtd_ref_medio = (self.__qtds_acum[pos_ini] + self.__qtds_acum[pos_ini+1])/2
                qtd0_medio = (self.__qtds0_acum[pos_ini] + self.__qtds0_acum[pos_ini+1])/2
                lift = qtd0_medio/self.__qtd0_tot
                alav = lift*self.__qtd_tot/qtd_ref_medio
        else:
            pos_ini = self.__qtds_acum_c.size - np.sum(self.__qtds_acum_c <= qtd_ref)
            if(self.__qtds_acum_c[pos_ini] == qtd_ref or pos_ini == 0):
                lift = self.__qtds1_acum_c[pos_ini]/qtd_ref
                alav = lift/frac
            else:
                qtd_ref_medio = (self.__qtds_acum_c[pos_ini] + self.__qtds_acum_c[pos_ini-1])/2
                qtd1_medio = (self.__qtds1_acum_c[pos_ini] + self.__qtds1_acum_c[pos_ini-1])/2
                lift = qtd1_medio/self.__qtd1_tot
                alav = lift*self.__qtd_tot/qtd_ref_medio
        return lift, alav
                
    def __calcula_ig(self):
        #Calcula a Entropia de Shannon
        def entropia_shannon(p1):
            p0 = 1 - p1
            if p0 == 0 or p1 == 0:
                return 0
            else:
                return -p0*np.log2(p0) - p1*np.log2(p1)
        
        p1 = self.__qtd1_tot/self.__qtd_tot
        entropia_ini = entropia_shannon(p1)

        #O último corte por definição não dá informação nenhuma, então nem faz a conta (por isso o [:-1])
        qtds_acum = self.__qtds_acum[:-1]
        qtds1_acum = self.__qtds1_acum[:-1]
        p1_acum = qtds1_acum/qtds_acum
        entropia_parcial = np.array([entropia_shannon(x) for x in p1_acum])

        qtds_acum_c = self.__qtds_acum_c[:-1]
        qtds1_acum_c = self.__qtds1_acum_c[:-1]
        p1c_acum = qtds1_acum_c/qtds_acum_c
        entropia_parcial_c = np.array([entropia_shannon(x) for x in p1c_acum])

        entropia = (entropia_parcial*qtds_acum + entropia_parcial_c*qtds_acum_c)/self.__qtd_tot
        #Coloca o valor [-1] que removemos no começo do calcula da entropia
        entropia = np.append(entropia, entropia_ini)
        self.__curva_ig = (entropia_ini - entropia)/entropia_ini
        
        self.__pos_max_ig = np.argmax(self.__curva_ig) #Pega as posições em que encontrou o máximo
        #Pega o valor máximo (tenta ver se pos_max é um vetor ou um número)
        try:
            self.__ig = self.__curva_ig[self.__pos_max_ig[0]] 
        except:
            self.__ig = self.__curva_ig[self.__pos_max_ig]
        #OBS: Note que o try except também poderia ser trocado aqui por self.__ig = np.max(self.__curva_ig[self.__pos_max_ig])
        
    def __calcula_ig_2d(self):
        #Calcula a Entropia de Shannon
        def entropia_shannon(p1):
            p0 = 1 - p1
            if p0 == 0 or p1 == 0:
                return 0
            else:
                return -p0*np.log2(p0) - p1*np.log2(p1)
        
        p1_ini = self.__qtd1_tot/self.__qtd_tot
        entropia_ini = entropia_shannon(p1_ini) 
        
        vetor_p0 = np.array([])
        vetor_p1 = np.array([])
        vetor_entropia = np.array([])
        vetor_ig = np.array([])
        #Temos a subtração -1 pois como já discutido, o último corte por definição não trás ganho de informação
        num_loop = self.__y_prob_unico.size-1
        #Subtrai mais um aqui pq queremos garantir que todo o loop tem um intervalo de resto
        for i in range(num_loop-1):
            start_loop2 = i + 1 #O segundo loop começa sempre 1 a frente pq queremos que sobre um intervalo de resto
            vetor_p0 = np.append(vetor_p0, np.repeat(self.__y_prob_unico[i], num_loop - start_loop2))
            qtd_acum = self.__qtds_acum[i]
            qtd1_acum = self.__qtds1_acum[i]
            p1 = qtd1_acum/qtd_acum
            entropia_parcial = entropia_shannon(p1)
            
            entropia_aux = entropia_parcial*qtd_acum/self.__qtd_tot
            
            #Segundo loop implicito nos vetores
            vetor_p1 = np.append(vetor_p1, self.__y_prob_unico[start_loop2:num_loop])
            qtd_acum_c = self.__qtds_acum_c[start_loop2:num_loop]
            qtd1_acum_c = self.__qtds1_acum_c[start_loop2:num_loop]
            p1c = qtd1_acum_c/qtd_acum_c
            entropia_parcial_c = np.array([entropia_shannon(x) for x in p1c])
            
            qtd_resto = self.__qtd_tot - qtd_acum - qtd_acum_c
            qtd1_acum_resto = self.__qtd1_tot - qtd1_acum - qtd1_acum_c
            p1r = qtd1_acum_resto/qtd_resto
            entropia_parcial_r = np.array([entropia_shannon(x) for x in p1r])
            
            entropia = entropia_aux + (entropia_parcial_c*qtd_acum_c + entropia_parcial_r*qtd_resto)/self.__qtd_tot
            vetor_entropia = np.append(vetor_entropia, entropia)
                
        self.__vetor_ig_2d = (entropia_ini - vetor_entropia)/entropia_ini
        self.__vetor_p0_ig_2d = vetor_p0
        self.__vetor_p1_ig_2d = vetor_p1
        
        self.__pos_max_ig_2d = np.argmax(self.__vetor_ig_2d) #Pega as posições em que encontrou o máximo
        try:
            self.__ig_2d = self.__vetor_ig_2d[self.__pos_max_ig_2d[0]] 
        except:
            self.__ig_2d = self.__vetor_ig_2d[self.__pos_max_ig_2d]
    
    def calcula_matriz_confusao(self, p0, p1, normalizado = False):
        if(p0 == p1):
            y_pred = np.array([0 if p <= p0 else 1 for p in self.__y_prob_inicial])
            y = self.__y
            frac_incerto = 0
        else:
            y_pred = np.array([0 if p <= p0 else 1 if p > p1 else np.nan for p in self.__y_prob_inicial])
            flag_na = np.isnan(y_pred, where = True)
            y_pred = y_pred[~flag_na]
            y = self.__y[~flag_na]
            frac_incerto = np.sum(flag_na)/self.__y_prob_inicial.size
        flag_vp = (y == y_pred)&(y_pred == 1)
        flag_vn = (y == y_pred)&(y_pred == 0)
        flag_fp = (y != y_pred)&(y_pred == 1)
        flag_fn = (y != y_pred)&(y_pred == 0)
        #Linhas: Preditos, Colunas: Labels
        #Normalização: Tem como objetivo obter as probabilidades condicionais
        #Isto é, dado que o modelo prediz um certo label, qual a prob de ser esse label mesmo e qual a prob de ser o outro label
        if(normalizado):
            vn = np.sum(flag_vn)
            fn = np.sum(flag_fn)
            norm_n = vn + fn
            fp = np.sum(flag_fp)
            vp = np.sum(flag_vp)
            norm_p = vp + fp
            matriz = np.matrix([[vn/norm_n, fn/norm_n], [fp/norm_p, vp/norm_p]])
        else:
            matriz = np.matrix([[np.sum(flag_vn), np.sum(flag_fn)], [np.sum(flag_fp), np.sum(flag_vp)]])
        return matriz, frac_incerto
    
    def __calcula_probabilidades_condicionais(self, matriz):
        soma = np.sum(matriz[0, :])
        if soma > 0:
            p00 = matriz[0, 0]/soma
        else:
            p00 = np.nan
        soma = np.sum(matriz[1, :])
        if soma > 0:
            p11 = matriz[1, 1]/soma
        else:
            p11 = np.nan
        return p00, p11
        
    def __calcula_acuracia(self, matriz):
        soma = np.sum(matriz)
        if soma > 0:
            acuracia = (matriz[0, 0] + matriz[1, 1])/soma
        else:
            acuracia = np.nan
        return acuracia
        
    def __calcula_acuracia_balanceada(self, matriz):
        soma_0 = matriz[0, 0] + matriz[1, 0]
        soma_1 = matriz[0, 1] + matriz[1, 1]
        if soma_0 > 0 and soma_1 > 0:
            acuracia_0 = matriz[0, 0]/soma_0
            acuracia_1 = matriz[1, 1]/soma_1
            acuracia_bal = (acuracia_0 + acuracia_1)*0.5
        else:
            acuracia_bal = np.nan
        return acuracia_bal
    
    def __calcula_metricas(self):
        self.__ordena_probs()
        if(self.__qtd0_tot*self.__qtd1_tot > 0):
            if(self.__y_prob_unico.size > 2):
                self.__calcula_roc()
                self.__calcula_ks()
                self.__liftF_10, self.__alavF_10 = self.__calcula_lift_alavancagem(decrescente = False, frac = 0.1)
                self.__liftF_20, self.__alavF_20 = self.__calcula_lift_alavancagem(decrescente = False, frac = 0.2)
                self.__liftV_10, self.__alavV_10 = self.__calcula_lift_alavancagem(decrescente = True, frac = 0.1)
                self.__liftV_20, self.__alavV_20 = self.__calcula_lift_alavancagem(decrescente = True, frac = 0.2)
                self.__calcula_ig()
                self.__calcula_ig_2d()
                probs_ig = self.valor_prob_ig()
                if(self.__p_corte == None):
                    self.__p_corte = probs_ig['Prob_Corte']
                if(np.sum(self.__p01_corte) == 0):
                    self.__p01_corte = np.array([probs_ig['Prob0_Corte'], probs_ig['Prob1_Corte']])
                self.matriz_confusao, _ = self.calcula_matriz_confusao(p0 = self.__p_corte, p1 = self.__p_corte)
                self.matriz_confusao_2d, self.__frac_incerto_2d = self.calcula_matriz_confusao(p0 = self.__p01_corte[0], p1 = self.__p01_corte[1])
                self.__p00, self.__p11 = self.__calcula_probabilidades_condicionais(self.matriz_confusao)
                self.__p00_2d, self.__p11_2d = self.__calcula_probabilidades_condicionais(self.matriz_confusao_2d)
                self.__acuracia = self.__calcula_acuracia(self.matriz_confusao)
                self.__acuracia_balanceada = self.__calcula_acuracia_balanceada(self.matriz_confusao)
                self.__acuracia_2d = self.__calcula_acuracia(self.matriz_confusao_2d)
                self.__acuracia_balanceada_2d = self.__calcula_acuracia_balanceada(self.matriz_confusao_2d)
            elif(self.__y_prob_unico.size > 1):
                self.__calcula_roc()
                self.__calcula_ks()
                self.__liftF_10, self.__alavF_10 = self.__calcula_lift_alavancagem(decrescente = False, frac = 0.1)
                self.__liftF_20, self.__alavF_20 = self.__calcula_lift_alavancagem(decrescente = False, frac = 0.2)
                self.__liftV_10, self.__alavV_10 = self.__calcula_lift_alavancagem(decrescente = True, frac = 0.1)
                self.__liftV_20, self.__alavV_20 = self.__calcula_lift_alavancagem(decrescente = True, frac = 0.2)
                self.__calcula_ig()
                probs_ig = self.valor_prob_ig()
                if(self.__p_corte == None):
                    self.__p_corte = probs_ig['Prob_Corte']
                self.matriz_confusao, _ = self.calcula_matriz_confusao(p0 = self.__p_corte, p1 = self.__p_corte)
                self.__p00, self.__p11 = self.__calcula_probabilidades_condicionais(self.matriz_confusao)
                self.__acuracia = self.__calcula_acuracia(self.matriz_confusao)
                self.__acuracia_balanceada = self.__calcula_acuracia_balanceada(self.matriz_confusao)
    
    def valor_prob_ig(self):
        #Retorna um pd.Series com as probs de corte encontradas no ganho de informação
        d = {}
        prob_corte = None
        p0_corte = None
        p1_corte = None
        if(self.__num_div != None):
            if(self.__pos_max_ig != None):
                prob_corte = self.__interv.pontos_medios_discretizacao()[self.__pos_max_ig]
            if(self.__pos_max_ig_2d != None):
                pos_p0_aux = int(self.__vetor_p0_ig_2d[self.__pos_max_ig_2d])
                pos_p1_aux = int(self.__vetor_p1_ig_2d[self.__pos_max_ig_2d])
                p0_corte = self.__interv.pontos_medios_discretizacao()[pos_p0_aux]
                p1_corte = self.__interv.pontos_medios_discretizacao()[pos_p1_aux]
        else:
            if(self.__pos_max_ig != None):
                prob_corte = (self.__y_prob_unico[self.__pos_max_ig] + self.__y_prob_unico[self.__pos_max_ig+1])/2 #Simetriza a prob decorte
            if(self.__pos_max_ig_2d != None):
                p0_corte = self.__vetor_p0_ig_2d[self.__pos_max_ig_2d] 
                p0_corte = (p0_corte + self.__y_prob_unico[np.searchsorted(self.__y_prob_unico, p0_corte)+1])/2 #Simetriza a prob decorte
                p1_corte = self.__vetor_p1_ig_2d[self.__pos_max_ig_2d]
                p1_corte = (p1_corte + self.__y_prob_unico[np.searchsorted(self.__y_prob_unico, p1_corte)+1])/2 #Simetriza a prob decorte
        d['Prob_Corte'] = prob_corte
        d['Prob0_Corte'] = p0_corte
        d['Prob1_Corte'] = p1_corte
        return d
    
    def valor_metricas(self, estatisticas_globais = True, probs_corte = True, probs_condicionais = True, lifts = True):
        #Retorna um pd.Series com as metricas calculadas
        #Esse formato é bom para criar dataframes
        d = {}
        if(estatisticas_globais):
            d['QTD'] = self.__qtd_tot
            d['QTD_0'] = self.__qtd_tot - self.__qtd1_tot
            d['QTD_1'] = self.__qtd1_tot
            d['Frac_0'] = (self.__qtd_tot - self.__qtd1_tot)/self.__qtd_tot
            d['Frac_1'] = self.__qtd1_tot/self.__qtd_tot
            d['Soma_Prob'] = self.__soma_probs
            d['Media_Prob'] = self.__soma_probs/self.__qtd_tot 
        d['AUC'] = self.__auc
        d['KS'] = self.__ks
        if(lifts):
            d['LiftF_10'] = self.__liftF_10
            d['LiftV_10'] = self.__liftV_10
            d['LiftF_20'] = self.__liftF_20
            d['LiftV_20'] = self.__liftV_20
            d['AlavF_10'] = self.__alavF_10
            d['AlavV_10'] = self.__alavV_10
            d['AlavF_20'] = self.__alavF_20
            d['AlavV_20'] = self.__alavV_20
        d['IG'] = self.__ig
        d['IG_2D'] = self.__ig_2d
        d['Frac_Incerto_2D'] = self.__frac_incerto_2d
        if(probs_corte):
            d.update(self.valor_prob_ig())
        d['Acurácia'] = self.__acuracia
        d['Acurácia_Balanceada'] = self.__acuracia_balanceada
        d['Acurácia_2D'] = self.__acuracia_2d
        d['Acurácia_Balanceada_2D'] = self.__acuracia_balanceada_2d
        if(self.__p00 != None and self.__p11 != None):
            d['Acurácia_Balanceada_Cond'] = (self.__p00 + self.__p11)*0.5
        else:
            d['Acurácia_Balanceada_Cond'] = None
        if(self.__p00_2d != None and self.__p11_2d != None):
            d['Acurácia_Balanceada_Cond_2D'] = (self.__p00_2d + self.__p11_2d)*0.5
        else:
            d['Acurácia_Balanceada_Cond_2D'] = None
        if(probs_condicionais):
            d['P(0|0)'] = self.__p00
            d['P(1|1)'] = self.__p11
            d['P_2D(0|0)'] = self.__p00_2d
            d['P_2D(1|1)'] = self.__p11_2d
        return pd.Series(d, index = d.keys())
    
    def curva_roc(self):
        if(self.__y_prob_unico.size > 1):
            curva_tnp = self.__curva_tnp
            curva_tvp = self.__curva_tvp
            auc = self.__auc
        else:
            curva_tnp = np.array([])
            curva_tvp = np.array([])
            auc = np.nan
        return curva_tnp, curva_tvp, auc
        
    def curva_revocacao(self):
        if(self.__y_prob_unico.size > 1):
            if(self.__num_div != None):
                y_prob_plot = [x for y in self.__interv.pares_minimo_maximo_discretizacao()[self.__y_prob_unico] for x in y] 
                curva_revoc0_plot = np.repeat(self.__curva_revoc0, 2)
                curva_revoc1_plot = np.repeat(self.__curva_revoc1, 2)
                pos_max = self.__interv.pontos_medios_discretizacao()[self.__pos_max_dif]
            else:
                y_prob_plot = self.__y_prob_unico
                curva_revoc0_plot = self.__curva_revoc0
                curva_revoc1_plot = self.__curva_revoc1
                pos_max = self.__y_prob_unico[self.__pos_max_dif]
            ks = self.__ks
        else:
            y_prob_plot = np.array([])
            curva_revoc0_plot = np.array([])
            curva_revoc1_plot = np.array([])
            pos_max = np.nan
            ks = np.nan
        return y_prob_plot, curva_revoc0_plot, curva_revoc1_plot, pos_max, ks
        
    def curva_informacao(self):
        if(self.__y_prob_unico.size > 1):
            if(self.__num_div != None):
                y_prob_plot = [x for y in self.__interv.pares_minimo_maximo_discretizacao()[self.__y_prob_unico] for x in y]
                curva_ig_plot = np.repeat(self.__curva_ig, 2)
                pos_max = self.__interv.pontos_medios_discretizacao()[self.__pos_max_ig]
                ig = self.__ig
                #Se eu quiser plotar o intervalo de prob "confiável" calculado com a informação 2D
                if(self.__y_prob_unico.size > 2):
                    pos_p0_aux = int(self.__vetor_p0_ig_2d[self.__pos_max_ig_2d])
                    pos_p1_aux = int(self.__vetor_p1_ig_2d[self.__pos_max_ig_2d])
                    p0_corte = self.__interv.pontos_medios_discretizacao()[pos_p0_aux]
                    p1_corte = self.__interv.pontos_medios_discretizacao()[pos_p1_aux]
                    ig_2d = self.__ig_2d
                else:
                    p0_corte = np.nan
                    p1_corte = np.nan
                    ig_2d = np.nan   
            else:
                y_prob_plot = self.__y_prob_unico
                curva_ig_plot = self.__curva_ig
                pos_max = self.__y_prob_unico[self.__pos_max_ig]
                ig = self.__ig
                if(self.__y_prob_unico.size > 2):
                    p0_corte = self.__vetor_p0_ig_2d[self.__pos_max_ig_2d]
                    p1_corte = self.__vetor_p1_ig_2d[self.__pos_max_ig_2d]
                    ig_2d = self.__ig_2d
                else:
                    p0_corte = np.nan
                    p1_corte = np.nan
                    ig_2d = np.nan
        else:
            y_prob_plot = np.array([])
            curva_ig_plot = np.array([])
            pos_max = np.nan
            ig = np.nan
            p0_corte = np.nan
            p1_corte = np.nan
            ig_2d = np.nan
        return y_prob_plot, curva_ig_plot, pos_max, ig, p0_corte, p1_corte, ig_2d
        
    def curva_informacao_2d(self):
        if(self.__y_prob_unico.size > 2):
            if(self.__num_div != None):
                x = [i for j in self.__interv.pares_minimo_maximo_discretizacao()[self.__vetor_p0_ig_2d.astype(int)] for i in j]
                y = [i for j in self.__interv.pares_minimo_maximo_discretizacao()[self.__vetor_p1_ig_2d.astype(int)] for i in j]
                x.extend(list(self.__interv.pontos_medios_discretizacao()[self.__vetor_p0_ig_2d.astype(int)]))
                y.extend(list(self.__interv.pontos_medios_discretizacao()[self.__vetor_p1_ig_2d.astype(int)]))
                z = np.repeat(self.__vetor_ig_2d, 2)
                z = np.append(z, self.__vetor_ig_2d)
                pos_p0_aux = int(self.__vetor_p0_ig_2d[self.__pos_max_ig_2d])
                pos_p1_aux = int(self.__vetor_p1_ig_2d[self.__pos_max_ig_2d])
                p0_corte = self.__interv.pontos_medios_discretizacao()[pos_p0_aux]
                p1_corte = self.__interv.pontos_medios_discretizacao()[pos_p1_aux]
                ig_2d = self.__ig_2d
            else:
                x = self.__vetor_p0_ig_2d
                y = self.__vetor_p1_ig_2d
                z = self.__vetor_ig_2d
                p0_corte = self.__vetor_p0_ig_2d[self.__pos_max_ig_2d]
                p1_corte = self.__vetor_p1_ig_2d[self.__pos_max_ig_2d]
                ig_2d = self.__ig_2d
            
        else:
            x = np.array([])
            y = np.array([])
            z = np.array([])
            p0_corte = np.nan
            p1_corte = np.nan
            ig_2d = np.nan
        return x, y, z, p0_corte, p1_corte, ig_2d
    
    def grafico_roc(self, roc_usual = True, figsize = [6, 4]):
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            curva_tnp, curva_tvp, auc = self.curva_roc()
            if(roc_usual):
                axs.plot(1-curva_tnp, curva_tvp, color = paleta_cores[0], label = 'Curva ROC')
                axs.plot([0, 1], [0, 1], color = 'k', linestyle = '--', label = 'Linha de Ref.')
                axs.set_xlabel('Taxa de Falso Positivo')
            else:
                axs.plot(curva_tnp, curva_tvp, color = paleta_cores[0], label = 'Curva ROC')
                axs.plot([0, 1], [1, 0], color = 'k', linestyle = '--', label = 'Linha de Ref.')
                axs.set_xlabel('Taxa de Verdadeiro Negativo')
            plt.gcf().text(1, 0.5, 'AUC = ' + '%.2g' % auc, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
            axs.set_ylabel('Taxa de Verdadeiro Positivo')
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.show()
        
    def grafico_revocacao(self, figsize = [6, 4]): 
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            y_prob_plot, curva_revoc0_plot, curva_revoc1_plot, pos_max, ks = self.curva_revocacao()
            axs.plot(y_prob_plot, curva_revoc0_plot, color = paleta_cores[0], alpha = 1.0, label = 'Revocação 0')
            axs.plot(y_prob_plot, curva_revoc1_plot, color = paleta_cores[1], alpha = 1.0, label = 'Revocação 1')
            axs.vlines(pos_max, 0, 1, color = 'k', linestyle = '--', label = 'Ponto KS')
            plt.gcf().text(1, 0.5, 'KS = ' + '%.2g' % ks, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            axs.set_xlabel('Probabilidade de Corte')
            axs.set_ylabel('Revocação')
            plt.show()
    
    def grafico_informacao(self, mostrar_ig_2d = False, figsize = [6, 4]):
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            y_prob_plot, curva_ig_plot, pos_max, ig, p0_corte, p1_corte, ig_2d = self.curva_informacao()
            axs.plot(y_prob_plot, curva_ig_plot, color = paleta_cores[0], label = 'Curva IG')
            axs.vlines(pos_max, 0, ig, color = 'k', linestyle = '--', label = 'Ganho Máx.')
            if(mostrar_ig_2d and ig_2d != np.nan):
                axs.vlines(p0_corte, 0, ig_2d, color = 'k', alpha = 0.5, linestyle = '--', label = 'Ganho Máx. 2D')
                axs.vlines(p1_corte, 0, ig_2d, color = 'k', alpha = 0.5, linestyle = '--')
                plt.gcf().text(1, 0.5, 'IG = ' + '%.2g' % ig + '\n' + 'IG 2D = ' + '%.2g' % ig_2d, 
                               bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                plt.gcf().text(1, 0.3, 'Prob Corte = ' + '%.2g' % pos_max + '\n\n' + 'Prob0 Corte = ' + '%.2g' % p0_corte + '\n' + 'Prob1 Corte = ' + '%.2g' % p1_corte, 
                               bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
            else:
                plt.gcf().text(1, 0.5, 'IG = ' + '%.2g' % ig, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                plt.gcf().text(1, 0.3, 'Prob Corte = ' + '%.2g' % pos_max, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            axs.set_xlabel('Probabilidade de Corte')
            axs.set_ylabel('Ganho de Informação')
            plt.show()
        
    def grafico_informacao_2d(self, plot_3d = True, figsize = [7, 6]):
        paleta_cores = sns.color_palette("colorblind")
        x, y, z, p0_corte, p1_corte, ig_2d = self.curva_informacao_2d()
        if(plot_3d):
            with sns.axes_style("whitegrid"):
                fig = plt.figure(figsize = figsize)
                axs = fig.add_subplot(111, projection='3d')
                #Constrói gradiente de uma cor até o branco (1,1,1) -> Lembrar que em RGB a mistura de todas as cores é que é o branco
                N = 256
                vals = np.ones((N, 4)) #A última componente (quarta) é o alpha que é o índice de transparência
                cor = paleta_cores[0]
                #Define as Cores RGB pelas componentes (no caso é o azul -> 0,0,255)
                vals[:, 0] = np.linspace(cor[0], 1, N)
                vals[:, 1] = np.linspace(cor[1], 1, N)
                vals[:, 2] = np.linspace(cor[2], 1, N)
                cmap = mpl.colors.ListedColormap(vals[::-1])
                axs.scatter(x, y, z, c = z, marker = 'o', cmap = cmap)
                axs.set_xlabel('Probabilidade de Corte 0')
                axs.set_ylabel('Probabilidade de Corte 1')
                axs.set_zlabel('Ganho de Informação')
                plt.show()
        else:
            with sns.axes_style("whitegrid"):
                fig, axs = plt.subplots(1, 1, figsize = figsize)
                #Faz uma mapa de cores com base em uma cor e mudando a transparência
                N = 256
                cor = paleta_cores[0]
                vals = np.ones((N, 4))
                vals[:, 0] = cor[0]
                vals[:, 1] = cor[1]
                vals[:, 2] = cor[2]
                cmap_linhas = mpl.colors.ListedColormap(vals[::-1])
                vals[:, 3] = np.linspace(0, 1, N)[::-1]
                cmap = mpl.colors.ListedColormap(vals[::-1])
                axs.tricontour(x, y, z, levels = 14, linewidths = 0.5, cmap = cmap_linhas)
                cntr = axs.tricontourf(x, y, z, levels = 14, cmap = cmap)
                cbar = plt.colorbar(cntr, ax = axs)
                cbar.ax.set_title('Ganho Info.')
                axs.scatter(p0_corte, p1_corte, color = 'k')
                axs.vlines(p0_corte, 0, p1_corte, color = 'k', alpha = 0.5, linestyle = '--')
                axs.hlines(p1_corte, 0, p0_corte, color = 'k', alpha = 0.5, linestyle = '--')
                plt.gcf().text(1, 0.8, 'IG 2D = ' + '%.2g' % ig_2d, bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                plt.gcf().text(1, 0.7, 'Prob0 Corte = ' + '%.2g' % p0_corte + '\n' + 'Prob1 Corte = ' + '%.2g' % p1_corte, 
                               bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                axs.set_xlabel('Probabilidade de Corte 0')
                axs.set_ylabel('Probabilidade de Corte 1')
                axs.set_xlim([min(x[0], y[0]), max(x[-1], y[-1])])
                axs.set_ylim([min(x[0], y[0]), max(x[-1], y[-1])])
                plt.show()

##############################

##############################

#Para funcionar direito, não pode haver nulos em y ou y_pred
class AletricasRegressao:
    
    def __init__(self, y, y_pred, y_ref = None, num_kendalltau = 10000):
        self.__y = y
        self.__y_pred = y_pred
        self.__y_ref = y_ref
        self.__num_kendalltau = num_kendalltau
        
        self.__qtd_tot = y.size
        
        self.__soma_preds = np.sum(y_pred)
        self.__soma_y = np.sum(y)
       
        self.__media_preds = self.__soma_preds/self.__qtd_tot
        self.__media_y = self.__soma_y/self.__qtd_tot
        
        self.__diff_y = self.__y - self.__y_pred
        self.__diff_ym = self.__y - self.__media_y
        if(y_ref == None):
            self.__diff_yr = self.__diff_ym
        else:
            self.__diff_yr = self.__y - self.__y_ref
        
        self.__mae = None
        self.__mse = None
        self.__rmse = None
        
        self.__rae = None
        self.__rse = None
        self.__rrse = None
     
        self.__rae_ref = None
        self.__rse_ref = None
        self.__rrse_ref = None
        
        self.__r1 = None
        self.__r2 = None
        self.__rr2 = None
        
        self.__r1_ref = None
        self.__r2_ref = None
        self.__rr2_ref = None
        
        self.__coef_kendalltau_conc = None
        self.__coef_kendalltau_disc = None
        self.__coef_kendalltau = None
        
        self.__calcula_metricas()
    
    def __calcula_mae(self):
        self.__mae = np.mean(np.abs(self.__diff_y))
        
    def __calcula_mse(self):
        self.__mse = np.mean(np.power(self.__diff_y, 2))
        
    def __calcula_rmse(self):
        self.__rmse = np.power(self.__mse, 0.5)
        
    def __calcula_rae(self):
        div = np.mean(np.abs(self.__diff_ym))
        if(div > 0):
            self.__rae = self.__mae/div
        else:
            self.__rae = np.nan

        div = np.mean(np.abs(self.__diff_yr))
        if(div > 0):
            self.__rae_ref = self.__mae/div
        else:
            self.__rae_ref = np.nan
            
    def __calcula_rse(self):
        div = np.mean(np.power(self.__diff_ym, 2))
        if(div > 0):
            self.__rse = self.__mse/div
        else:
            self.__rse = np.nan

        div = np.mean(np.power(self.__diff_yr, 2))
        if(div > 0):
            self.__rse_ref = self.__mse/div
        else:
            self.__rse_ref = np.nan
          
    def __calcula_rrse(self):
        if(np.isnan(self.__rse)):
            self.__rrse = np.nan
        else:
            self.__rrse = np.power(self.__rse, 0.5)

        if(np.isnan(self.__rse_ref)):
            self.__rrse_ref = np.nan
        else:
            self.__rrse_ref = np.power(self.__rse_ref, 0.5)
        
    def __calcula_r1(self):
        self.__r1 = 1 - self.__rae
        self.__r1_ref = 1 - self.__rae_ref
            
    def __calcula_r2(self):
        self.__r2 = 1 - self.__rse
        self.__r2_ref = 1 - self.__rse_ref
            
    def __calcula_rr2(self):
        self.__rr2 = 1 - self.__rrse
        self.__rr2_ref = 1 - self.__rrse_ref
    
    def __calcula_coeficiente_kendalltau(self):
    
        #Remove os valores absolutos e pega só a ordem de crescimento (transforma em ordinal)
        def transforma_ordinal(vetor):
            v_unicos, inds_inverso = np.unique(vetor, return_inverse = True)
            v_contador = np.arange(0, v_unicos.size)
            return v_contador[inds_inverso]
        
        y_ordinal = transforma_ordinal(self.__y)
        y_pred_ordinal = transforma_ordinal(self.__y_pred)
        #Ordena os y_ordinal utilizando a predição
        inds_ordenado = np.argsort(y_pred_ordinal)
        y_ord = y_ordinal[inds_ordenado]
        y_pred_ord = y_pred_ordinal[inds_ordenado]

        #Agora queremos ver quanto a ordenação pela predição consegue ordenar o y_ordinal (coeficiente Kandall Tau modificado)
        pares_valores = np.array(list(zip(y_ord, y_pred_ord)))
        def checa_ordenacao(pares_indices, pares_valores, i):
            ind_a = pares_indices[i]
            ind_b = pares_indices[i+1]
            a = pares_valores[ind_a]
            b = pares_valores[ind_b]
            return (a[0] > a[1] and b[0] > b[1]) or (a[0] < a[1] and b[0] < b[1]) or (a[0] == a[1] and b[0] == b[1])
        pares_indices = np.random.choice(y_ord.size, self.__num_kendalltau + 1, replace = True)
        vetor_bool = np.array([checa_ordenacao(pares_indices, pares_valores, i) for i in range(0, pares_indices.size-1)])
        self.__coef_kendalltau_conc = np.sum(vetor_bool)/vetor_bool.size
        self.__coef_kendalltau_disc = 1 - self.__coef_kendalltau_conc
        self.__coef_kendalltau = self.__coef_kendalltau_conc - self.__coef_kendalltau_disc
    
    def __calcula_metricas(self):
        if(self.__qtd_tot > 0):
            self.__calcula_mae()
            self.__calcula_mse()
            self.__calcula_rmse()
            
            self.__calcula_rae()
            self.__calcula_rse()
            self.__calcula_rrse()
            
            self.__calcula_r1()
            self.__calcula_r2()
            self.__calcula_rr2()
            
            if(self.__qtd_tot > 1 and self.__num_kendalltau > 0):
                self.__calcula_coeficiente_kendalltau()
    
    def valor_media_alvo(self):
        return self.__media_y
    
    def valor_metricas(self, estatisticas_globais = True, metricas_ref = True, alga_signif = 0, conv_str = False):
        #Retorna um pd.Series com as metricas calculadas
        #Esse formato é bom para criar dataframes
        d = {}
        if(estatisticas_globais):
            d['QTD'] = self.__qtd_tot
            d['Soma_Alvo'] = self.__soma_y
            d['Soma_Pred'] = self.__soma_preds
            d['Media_Alvo'] = self.__media_y
            d['Media_Pred'] = self.__media_preds
        d['MAE'] = self.__mae
        d['MSE'] = self.__mse
        d['RMSE'] = self.__rmse
        d['RAE'] = self.__rae
        d['RSE'] = self.__rse
        d['RRSE'] = self.__rrse
        if(metricas_ref):
            d['RAE_ref'] = self.__rae_ref
            d['RSE_ref'] = self.__rse_ref
            d['RRSE_ref'] = self.__rrse_ref
        d['R1'] = self.__r1
        d['R2'] = self.__r2
        d['RR2'] = self.__rr2
        if(metricas_ref):
            d['R1_ref'] = self.__r1_ref
            d['R2_ref'] = self.__r2_ref
            d['RR2_ref'] = self.__rr2_ref
        d['KendallTau_Conc'] = self.__coef_kendalltau_conc
        d['KendallTau_Disc'] = self.__coef_kendalltau_disc
        d['KendallTau'] = self.__coef_kendalltau
        if(alga_signif > 0):
            str_conv = '%.' + str(alga_signif) + 'g'
            for key in d.keys():
                try:
                    d[key] = float(str_conv % d[key])
                except:
                    d[key] = np.nan
        if(conv_str):
            for key in d.keys():
                try:
                    d[key] = str(d[key])
                except:
                    d[key] = np.nan
        return pd.Series(d, index = d.keys())
        
import numpy as np
import pandas as pd

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D

from AleTransforms import *
from AleDatasetAnalysis import *
from AleMetrics import *

class AvaliaClassificacao:

    def __init__(self, df, col_alvo, col_prob = None, num_div_prob = None, p_corte = None, p01_corte = [0, 0], num_div = None, frac_cat = 0):
    
        self.distribuicoes = DistribuicoesDataset(df, num_div, frac_cat)
        self.__dict_intervs, self.__dict_filtroscat = self.distribuicoes.retorna_trata_dataset().retorna_instancias_tratamento()
        self.__df_tratado = self.distribuicoes.retorna_trata_dataset().aplica_transformacao(df, usar_ponto_medio = False, considera_resto = True, usar_str = False)
        
        self.__y = df[col_alvo].values
        self.__col_alvo = col_alvo
        self.__col_prob = col_prob
        
        if(col_prob != None):
            self.__y_prob = df[col_prob].values
            self.__num_div_prob = num_div_prob
            
            #Calculas as métricas gerais do dataset
            self.metricas_gerais = AletricasClassificacao(self.__y, self.__y_prob, num_div = self.__num_div_prob, p_corte = p_corte, p01_corte = p01_corte)
            #Probabilidades de Corte para Avaliação de Tomada de Decisão (Usa do Ganho de Informação se não for passado)
            probs_ig = self.metricas_gerais.valor_prob_ig()
            if(p_corte == None):
                self.__p_corte = probs_ig['Prob_Corte']
            else:
                self.__p_corte = p_corte
            if(np.sum(np.array(p01_corte)) == 0):
                self.__p01_corte = [probs_ig['Prob0_Corte'], probs_ig['Prob1_Corte']]
            else:
                self.__p01_corte = p01_corte
            
            #OBS: Note que, dessa forma, se for o dataset de treino, podemos não passar as probs e usar como corte o decidido pelo IG no próprio dataset
            #Porém, se for um dataset de Validação ou Teste, podemos passar as probs de corte que foram obtidas na avaliação do dataset de Treino
            
        else:
            self.__y_prob = None
            self.__num_div_prob = None
            self.__p_corte = None
            self.__p01_corte = [0, 0]
        
        self.__dict_valores = {}
        self.__dict_qtds = {}
        
        self.__dict_qtds1 = {}
        self.__dict_prob1 = {}
        self.__dict_ig = {}
        self.__dict_ig_por_bit = {} #Ganho de Informação por Bit (quantidade de valores únicos em log2)
        
        self.__dict_soma_prob = {}
        self.__dict_media_prob = {}
        self.__dict_metricas = {}
    
    def colunas_metricas_condicionais_prontas(self):
        return self.__dict_valores.keys()
    
    def calcula_metricas_condicionais(self, col_ref = []):
        num_linhas, _, colunas = self.distribuicoes.info_dataset()
        
        #Transforma uma string única em uma lista
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
        
        if(len(col_ref) != 0):
            colunas = col_ref
            
        for col_ref in colunas:
            flag_na = self.distribuicoes.retorna_flag_na(col_ref)
            valores = self.__df_tratado.loc[~flag_na, col_ref].astype(int).values
            y = self.__y[~flag_na]
            
            inds_ordenado = np.argsort(valores)
            valores_unico, primeira_ocorrencia, qtds = np.unique(valores[inds_ordenado], return_index = True, return_counts = True)
            self.__dict_valores[col_ref] = valores_unico
            self.__dict_qtds[col_ref] = qtds
            
            y_agrup = np.split(y[inds_ordenado], primeira_ocorrencia[1:])
            qtds1 = np.array([np.sum(v) for v in y_agrup])
            probs1 = qtds1/qtds
            self.__dict_qtds1[col_ref] = qtds1
            self.__dict_prob1[col_ref] = probs1
            
            #Calcula a Entropia de Shannon
            def entropia_shannon(p1):
                p0 = 1 - p1
                if p0 == 0 or p1 == 0:
                    return 0
                else:
                    return -p0*np.log2(p0) - p1*np.log2(p1)
            
            num_linhas_sem_na = num_linhas - np.sum(flag_na)
            
            entropia_ini = entropia_shannon(np.sum(qtds1)/num_linhas_sem_na)
            entropias_parciais = np.array([entropia_shannon(x) for x in probs1])
            entropia = np.sum(entropias_parciais*qtds)/num_linhas_sem_na
            ig = (entropia_ini - entropia)/entropia_ini
            self.__dict_ig[col_ref] = ig
            qtd_unicos = valores_unico.size
            if(qtd_unicos > 1):
                self.__dict_ig_por_bit[col_ref] = ig/np.log2(qtd_unicos)
            else:
                self.__dict_ig_por_bit[col_ref] = 0
            
            if(self.__col_prob != None):
                y_prob = self.__y_prob[~flag_na]
                y_prob_agrup = np.split(y_prob[inds_ordenado], primeira_ocorrencia[1:])
                soma_prob = np.array([np.sum(v) for v in y_prob_agrup])
                self.__dict_soma_prob[col_ref] = soma_prob
                self.__dict_media_prob[col_ref] = soma_prob/qtds
                self.__dict_metricas[col_ref] = np.array([AletricasClassificacao(y_agrup[i], y_prob_agrup[i], num_div = self.__num_div_prob,
                                                          p_corte = self.__p_corte, p01_corte = self.__p01_corte) for i in range(valores_unico.size)])
                                                          
        #Ordena os Ganhos de Informação
        self.__dict_ig = dict(reversed(sorted(self.__dict_ig.items(), key = lambda x: x[1])))
        self.__dict_ig_por_bit = dict(reversed(sorted(self.__dict_ig_por_bit.items(), key = lambda x: x[1])))
    
    def ganho_info(self):
        return pd.Series(self.__dict_ig, index = self.__dict_ig.keys())

    def ganho_info_por_bit(self):
        return pd.Series(self.__dict_ig_por_bit, index = self.__dict_ig_por_bit.keys())
    
    def valor_metricas_condicionais(self, col_ref):
        df = pd.DataFrame()
        if(col_ref in self.__dict_valores.keys()):
            
            df['Valores'] = self.__dict_valores[col_ref]
            if(col_ref in self.__dict_intervs.keys()):
                df['Labels'] = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            elif(col_ref in self.__dict_filtroscat.keys()):
                df['Labels'] = self.__dict_filtroscat[col_ref].strings_categorias()
            df['QTD'] = self.__dict_qtds[col_ref]
            df['QTD_0'] = self.__dict_qtds[col_ref] - self.__dict_qtds1[col_ref]
            df['QTD_1'] = self.__dict_qtds1[col_ref]
            df['Frac_0'] = 1 - self.__dict_prob1[col_ref]
            df['Frac_1'] = self.__dict_prob1[col_ref]
            
            if(self.__col_prob != None):
                df['Soma_Prob'] = self.__dict_soma_prob[col_ref]
                df['Media_Prob'] = self.__dict_media_prob[col_ref]
                df['Metricas'] = self.__dict_metricas[col_ref]
                df = pd.concat([df, df['Metricas'].apply(lambda x: x.valor_metricas(estatisticas_globais = False))], axis = 1)
                df = df.drop('Metricas', axis = 1)

        return df
    
    def curva_probabilidade_condicional(self, col_ref):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
        prob1 = self.__dict_prob1[col_ref]
        if(self.__col_prob != None):
            media_prob = self.__dict_media_prob[col_ref]
        else:
            media_prob = None
            
        #Ordena por média do alvo se forem categorias (e podemos rearranjar a ordem)
        if(tipo == 'categoria'):
            inds_ordenado = np.argsort(prob1)
            valores = valores[inds_ordenado]
            labels = labels[inds_ordenado]
            prob1 = prob1[inds_ordenado]
            if(self.__col_prob != None):
                media_prob = media_prob[inds_ordenado]
            
        return valores, labels, prob1, media_prob, tipo
        
    def curvas_metricas_condicionais(self, col_ref, metricas):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
            
        df = self.valor_metricas_condicionais(col_ref)            
        valores_metricas = []
        for metrica in metricas:
            valores_metricas.append(df[metrica].values)
            
        return valores, labels, valores_metricas, tipo
    
    def grafico_probabilidade_condicional(self, col_ref, ymax = 0, conv_str = True, figsize = [6, 4]):
        if(col_ref in self.__dict_valores.keys()):
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            
            #Plot a curva de probabilidade dada pelo Alvo e pela Prob do Classificador
            with sns.axes_style("whitegrid"):
                fig, axs = plt.subplots(1, 1, figsize = figsize)
                valores, labels, prob1, media_prob, tipo = self.curva_probabilidade_condicional(col_ref)
                ig = self.__dict_ig[col_ref]
                ig_por_bit = self.__dict_ig_por_bit[col_ref]
                if(labels is not None):
                    if(tipo == 'intervalo'):
                        axs.bar(valores, prob1, color = paleta_cores[0], label = 'Real')
                        axs.set_xticks(valores)
                        axs.set_xticklabels(labels, rotation = 90)
                        if(media_prob is not None):
                            axs.plot(valores, media_prob, color = paleta_cores[1], linewidth = 2, label = 'Classificador')
                    elif(tipo == 'categoria'):
                        axs.bar(labels, prob1, color = paleta_cores[0], label = 'Real')
                        if(media_prob is not None):
                            axs.plot(labels, media_prob, color = paleta_cores[1], linewidth = 2, label = 'Classificador')
                else:
                    if(conv_str):
                        valores = valores.astype(str)
                    axs.bar(valores, prob1, color = paleta_cores[0], label = 'Real')
                    if(media_prob is not None):
                        axs.plot(valores, media_prob, color = paleta_cores[1], linewidth = 2, label = 'Classificador')
                plt.gcf().text(1, 0.5, 'IG = ' + '%.2g' % ig + '\n' + 'IG/Bit = ' + '%.2g' % ig_por_bit, 
                               bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                axs.set_xlabel(col_ref)
                axs.set_ylabel('Probabilidade de 1')
                if(ymax > 0 and ymax <= 1):
                    axs.set_ylim([0, ymax])
                axs.legend(bbox_to_anchor=(1.15, 1), loc='upper left')
                plt.show()

    def grafico_metricas_condicionais(self, col_ref, metricas, conv_str = True, ylim = [0, 0], figsize = [6, 4]):
        if(col_ref in self.__dict_qtds1.keys()):
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico 
            #Plot a curva de métrica em função da coluna de referência
            with sns.axes_style("whitegrid"):
                fig, axs = plt.subplots(1, 1, figsize = figsize)
                valores, labels, valores_metricas, tipo = self.curvas_metricas_condicionais(col_ref, metricas)
                for i in range(len(metricas)):
                    valores_metrica = valores_metricas[i]
                    if(labels is not None):
                        if(tipo == 'intervalo'):
                            if(valores.size > 1):
                                axs.plot(valores, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                            else:
                                axs.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                            axs.set_xticks(valores)
                            axs.set_xticklabels(labels, rotation = 90)
                        elif(tipo == 'categoria'):
                            if(valores.size > 1):
                                axs.plot(labels, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                            else:
                                axs.scatter(labels, valores_metrica, color = paleta_cores[i], label = metricas[i])
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        if(valores.size > 1):
                            axs.plot(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                        else:
                            axs.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                axs.set_xlabel(col_ref)
                axs.set_ylabel('Metricas')
                if(ylim[1] > ylim[0]):
                    axs.set_ylim(ylim)
                axs.legend(bbox_to_anchor=(1.15, 1), loc='upper left')
                plt.show()

##############################

##############################

class AvaliaDatasetsClassificacao:

    def __init__(self, dict_dfs, col_alvo, col_prob = None, num_div_prob = None, num_div = None, frac_cat = 0, chave_treino = 'Treino'):
        self.__dict_dfs = dict_dfs
        self.__num_dfs = len(dict_dfs)
        self.__chave_treino = chave_treino
        
        self.__dict_avaliaclf = {}
        if(self.__chave_treino in self.__dict_dfs.keys()):
            avaliaclf_treino = AvaliaClassificacao(self.__dict_dfs[self.__chave_treino], col_alvo, col_prob, num_div_prob = num_div_prob, num_div = num_div, frac_cat = frac_cat)
            #Probabilidades de Corte para Avaliação de Tomada de Decisão
            probs_ig = avaliaclf_treino.metricas_gerais.valor_prob_ig()
            p_corte = probs_ig['Prob_Corte']
            p01_corte = [probs_ig['Prob0_Corte'], probs_ig['Prob1_Corte']]
            self.__dict_avaliaclf[self.__chave_treino] = avaliaclf_treino
        for chave in self.__dict_dfs.keys():
            if(chave != self.__chave_treino):
                self.__dict_avaliaclf[chave] = AvaliaClassificacao(self.__dict_dfs[chave], col_alvo, col_prob, num_div_prob, p_corte, p01_corte, num_div, frac_cat)
        
    def avaliadores_individuais(self):
        return self.__dict_avaliaclf
        
    def calcula_metricas_condicionais(self, col_ref = []):
        for chave in self.__dict_dfs.keys():
            self.__dict_avaliaclf[chave].calcula_metricas_condicionais(col_ref)
    
    def valor_metricas(self, estatisticas_globais = True, probs_corte = True, probs_condicionais = True, lifts = True):
        df = pd.DataFrame(self.__dict_avaliaclf[self.__chave_treino].metricas_gerais.valor_metricas(estatisticas_globais, probs_corte, probs_condicionais, lifts), columns = [self.__chave_treino])
        for chave in self.__dict_dfs.keys():
            if(chave != self.__chave_treino):
                df[chave] = self.__dict_avaliaclf[chave].metricas_gerais.valor_metricas(estatisticas_globais, probs_corte, probs_condicionais, lifts)
        return df
    
    def grafico_roc(self, roc_usual = True, figsize = [6, 4]):
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            i = 0
            for chave in self.__dict_dfs.keys():
                curva_tnp, curva_tvp, auc = self.__dict_avaliaclf[chave].metricas_gerais.curva_roc()
                if(roc_usual):
                    axs.plot(1-curva_tnp, curva_tvp, color = paleta_cores[i], label = chave)
                else:
                    axs.plot(curva_tnp, curva_tvp, color = paleta_cores[i], label = chave)
                i = i + 1
            if(roc_usual):
                axs.plot([0, 1], [0, 1], color = 'k', linestyle = '--', label = 'Linha de Ref.')
                axs.set_xlabel('Taxa de Falso Positivo')
            else:
                axs.plot([0, 1], [1, 0], color = 'k', linestyle = '--', label = 'Linha de Ref.')
                axs.set_xlabel('Taxa de Verdadeiro Negativo')
            axs.set_ylabel('Taxa de Verdadeiro Positivo')
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.show()

    def grafico_revocacao(self, figsize = [6, 4]): 
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            i = 0
            for chave in self.__dict_dfs.keys():
                y_prob_plot, curva_revoc0_plot, curva_revoc1_plot, pos_max, ks = self.__dict_avaliaclf[chave].metricas_gerais.curva_revocacao()
                axs.plot(y_prob_plot, curva_revoc0_plot, color = paleta_cores[i], alpha = 0.6)
                axs.plot(y_prob_plot, curva_revoc1_plot, color = paleta_cores[i], alpha = 0.4)
                axs.vlines(pos_max, 0, 1, color = paleta_cores[i], linestyle = '--', label = chave)
                i = i + 1
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            axs.set_xlabel('Probabilidade de Corte')
            axs.set_ylabel('Revocação')
            plt.show()
            
    def grafico_informacao(self, mostrar_ig_2d = False, figsize = [6, 4]):
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            i = 0
            for chave in self.__dict_dfs.keys():
                y_prob_plot, curva_ig_plot, pos_max, ig, p0_corte, p1_corte, ig_2d = self.__dict_avaliaclf[chave].metricas_gerais.curva_informacao()
                axs.plot(y_prob_plot, curva_ig_plot, color = paleta_cores[i], label = chave)
                axs.vlines(pos_max, 0, ig, color = paleta_cores[i], linestyle = '--')
                if(mostrar_ig_2d and ig_2d != np.nan):
                    axs.vlines(p0_corte, 0, ig_2d, color = paleta_cores[i], alpha = 0.5, linestyle = '--')
                    axs.vlines(p1_corte, 0, ig_2d, color = paleta_cores[i], alpha = 0.5, linestyle = '--')
                i = i + 1
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            axs.set_xlabel('Probabilidade de Corte')
            axs.set_ylabel('Ganho de Informação')
            plt.show()
            
    def grafico_informacao_2d(self, plot_3d = True, figsize = [7, 6]):
        paleta_cores = sns.color_palette("colorblind")
        if(plot_3d):
            with sns.axes_style("whitegrid"):
                fig = plt.figure(figsize = figsize)
                axs = fig.add_subplot(111, projection='3d')
                i = 0
                hlds = []
                for chave in self.__dict_dfs.keys():
                    x, y, z, p0_corte, p1_corte, ig_2d = self.__dict_avaliaclf[chave].metricas_gerais.curva_informacao_2d()
                    N = 256
                    vals = np.ones((N, 4)) #A última componente (quarta) é o alpha que é o índice de transparência
                    cor = paleta_cores[i]
                    #Define as Cores RGB pelas componentes (no caso é o azul -> 0,0,255)
                    vals[:, 0] = np.linspace(cor[0], 1, N)
                    vals[:, 1] = np.linspace(cor[1], 1, N)
                    vals[:, 2] = np.linspace(cor[2], 1, N)
                    cmap = mpl.colors.ListedColormap(vals[::-1])
                    axs.scatter(x, y, z, c = z, marker = 'o', cmap = cmap)
                    hlds.append(mpl.patches.Patch(color = cor, label = chave))
                    i = i + 1
                axs.set_xlabel('Probabilidade de Corte 0')
                axs.set_ylabel('Probabilidade de Corte 1')
                axs.set_zlabel('Ganho de Informação')
                axs.legend(handles = hlds, bbox_to_anchor = (1.3, 1), loc = 'upper left')
                plt.show()
        else:
            with sns.axes_style("whitegrid"):
                fig, axs = plt.subplots(1, 1, figsize = figsize)
                i = 0
                hlds = []
                mini = 1
                maxi = 0
                for chave in self.__dict_dfs.keys():
                    x, y, z, p0_corte, p1_corte, ig_2d = self.__dict_avaliaclf[chave].metricas_gerais.curva_informacao_2d()
                    mini = min(mini, min(x[0], y[0]))
                    maxi = max(maxi, max(x[-1], y[-1]))
                    N = 256
                    cor = paleta_cores[i]
                    vals = np.ones((N, 4))
                    vals[:, 0] = cor[0]
                    vals[:, 1] = cor[1]
                    vals[:, 2] = cor[2]
                    cmap_linhas = mpl.colors.ListedColormap(vals[::-1])
                    vals[:, 3] = np.linspace(0, 1, N)[::-1]
                    cmap = mpl.colors.ListedColormap(vals[::-1])
                    axs.tricontour(x, y, z, levels = 14, linewidths = 1.0, cmap = cmap_linhas)
                    #cntr = axs.tricontourf(x, y, z, levels = 14, cmap = cmap)
                    axs.scatter(p0_corte, p1_corte, color = cor)
                    axs.vlines(p0_corte, 0, p1_corte, color = cor, alpha = 0.5, linestyle = '--')
                    axs.hlines(p1_corte, 0, p0_corte, color = cor, alpha = 0.5, linestyle = '--')
                    hlds.append(mpl.patches.Patch(color = cor, label = chave))
                    i = i + 1
                axs.set_xlabel('Probabilidade de Corte 0')
                axs.set_ylabel('Probabilidade de Corte 1')
                axs.set_xlim([mini, maxi])
                axs.set_ylim([mini, maxi])
                axs.legend(handles = hlds, bbox_to_anchor = (1.3, 1), loc = 'upper left')
                plt.show()
                
    def grafico_distribuicao(self, col_ref = [], conv_str = True, figsize = [6, 4]):
        _, _, colunas = self.__dict_avaliaclf[self.__chave_treino].distribuicoes.info_dataset()
    
        #Transforma uma string única em uma lista
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
    
        if(len(col_ref) != 0):
            colunas = col_ref
            
        for col_ref in colunas:
            if(col_ref in self.__dict_avaliaclf[self.__chave_treino].colunas_metricas_condicionais_prontas()):
                paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
                
                #Plota informações da distribuição da variável de referência nos dados
                with sns.axes_style("whitegrid"):
                    fig, axs = plt.subplots(1, 1, figsize = figsize)
                    i = 0
                    for chave in self.__dict_dfs.keys():
                        valores, frac, tipo = self.__dict_avaliaclf[chave].distribuicoes.curva_distribuicao(col_ref)
                        if(tipo == 'intervalo'):
                            axs.fill_between(valores, frac, color = paleta_cores[i], alpha = 0.5)
                            axs.plot(valores, frac, color = paleta_cores[i], label = chave)
                            axs.set_ylabel('Fração/L')
                        elif(tipo == 'categoria'):
                            axs.bar(valores, frac, color = paleta_cores[i], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[i], label = chave)
                            axs.set_ylabel('Fração')
                        else:
                            if(conv_str):
                                valores = valores.astype(str)
                            axs.bar(valores, frac, color = paleta_cores[i], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[i], label = chave)
                            axs.set_ylabel('Fração')
                        i = i + 1
                    axs.set_xlabel(col_ref)
                    axs.set_ylim(bottom = 0.0)
                    axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                    plt.show()
                
    def grafico_probabilidade_condicional(self, col_ref, ymax = 0, conv_str = True, figsize_base = [6, 4]):
        if(col_ref in self.__dict_avaliaclf[self.__chave_treino].colunas_metricas_condicionais_prontas()):
        
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            
            #Plot a curva de probabilidade dada pelo Alvo e pela Prob do Classificador
            with sns.axes_style("whitegrid"):
                if(ymax > 0 and ymax <= 1):
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]], 
                                            sharex = True, sharey = True)
                    plt.subplots_adjust(wspace = 0.01)
                else:
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]])
                i = 0
                hlds = []             
                
                for chave in self.__dict_dfs.keys():
                    if(self.__num_dfs > 1):
                        ax = axs[i]
                    else:
                        ax = axs
                    valores, labels, prob1, media_prob, tipo = self.__dict_avaliaclf[chave].curva_probabilidade_condicional(col_ref)
                    if(labels is not None):
                        if(tipo == 'intervalo'):
                            ax.bar(valores, prob1, color = paleta_cores[i], label = chave)
                            ax.set_xticks(valores)
                            ax.set_xticklabels(labels, rotation = 90)
                            if(media_prob is not None):
                                if(valores.size > 1):
                                    ax.plot(valores, media_prob, color = 'black', linewidth = 2)
                                else:
                                    ax.scatter(valores, media_prob, color = 'black')
                        elif(tipo == 'categoria'):
                            ax.bar(labels, prob1, color = paleta_cores[i], label = chave)
                            if(media_prob is not None):
                                if(valores.size > 1):
                                    ax.plot(labels, media_prob, color = 'black', linewidth = 2)
                                else:
                                    ax.scatter(labels, media_prob, color = 'black')
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        ax.bar(valores, prob1, color = paleta_cores[i], label = chave)
                        if(media_prob is not None):
                            if(valores.size > 1):
                                ax.plot(valores, media_prob, color = 'black', linewidth = 2)
                            else:
                                ax.scatter(valores, media_prob, color = 'black')      
                    if(ymax > 0 and ymax <= 1):
                        ax.set_ylim([0, ymax])
                        if(i == 0):
                            ax.set_xlabel(col_ref)
                            ax.set_ylabel('Probabilidade de 1')
                    else:
                        ax.set_xlabel(col_ref)
                        ax.set_ylabel('Probabilidade de 1')
                    ax.set_title(chave)
                    hlds.append(mpl.patches.Patch(color = paleta_cores[i], label = chave))
                    i = i + 1
                hlds.append(mpl.patches.Patch(color = 'k', label = 'Classificador'))
                plt.legend(handles = hlds, bbox_to_anchor = (1.3, 1), loc = 'upper left')
                plt.show()
                
    def grafico_metricas_condicionais(self, col_ref, metricas, ylim = [0, 0], conv_str = True, figsize_base = [6, 4]):
        if(col_ref in self.__dict_avaliaclf[self.__chave_treino].colunas_metricas_condicionais_prontas()):
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            with sns.axes_style("whitegrid"):
                if(ylim[1] > ylim[0]):
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]], 
                                            sharex = True, sharey = True)
                    plt.subplots_adjust(wspace = 0.01)
                else:
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]])
                j = 0
                hlds = []
                for chave in self.__dict_dfs.keys():
                    if(self.__num_dfs > 1):
                        ax = axs[j]
                    else:
                        ax = axs

                    valores, labels, valores_metricas, tipo = self.__dict_avaliaclf[chave].curvas_metricas_condicionais(col_ref, metricas)
                    for i in range(len(metricas)):
                        valores_metrica = valores_metricas[i]
                        if(labels is not None):
                            if(tipo == 'intervalo'):
                                if(valores.size > 1):
                                    ax.plot(valores, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                                else:
                                    ax.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                                ax.set_xticks(valores)
                                ax.set_xticklabels(labels, rotation = 90)
                            elif(tipo == 'categoria'):
                                if(valores.size > 1):
                                    ax.plot(labels, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                                else:
                                    ax.scatter(labels, valores_metrica, color = paleta_cores[i], label = metricas[i])
                        else:
                            if(conv_str):
                                valores = valores.astype(str)
                            if(valores.size > 1):
                                ax.plot(valores, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                            else:
                                ax.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                                    
                        if(chave == self.__chave_treino):
                            hlds.append(mpl.patches.Patch(color = paleta_cores[i], label = metricas[i]))
                    
                    if(ylim[1] > ylim[0]):
                        ax.set_ylim(ylim)
                        if(j == 0):
                            ax.set_xlabel(col_ref)
                            ax.set_ylabel('Metricas')
                    else:
                        ax.set_xlabel(col_ref)
                        ax.set_ylabel('Metricas')
                    ax.set_title(chave)
                    j = j + 1
                plt.legend(handles = hlds, bbox_to_anchor = (1.3, 1), loc = 'upper left')
                plt.show()

###########################################

###########################################

class AvaliaRegressao:

    def __init__(self, df, col_alvo, col_pred = None, y_ref = None, num_kendalltau = 10000, num_div = None, frac_cat = 0):
        
        self.distribuicoes = DistribuicoesDataset(df, num_div, frac_cat)
        self.__dict_intervs, self.__dict_filtroscat = self.distribuicoes.retorna_trata_dataset().retorna_instancias_tratamento()
        self.__df_tratado = self.distribuicoes.retorna_trata_dataset().aplica_transformacao(df, usar_ponto_medio = False, considera_resto = True, usar_str = False)
        
        self.__y = df[col_alvo].values
        self.__col_alvo = col_alvo
        self.__col_pred = col_pred
        self.__num_kendalltau = num_kendalltau
        
        if(col_pred != None):
            self.__y_pred = df[col_pred].values
            
            #Calculas as métricas gerais do dataset
            self.metricas_gerais = AletricasRegressao(self.__y, self.__y_pred, y_ref = y_ref, num_kendalltau = self.__num_kendalltau)
            
            #Valor de referência para as métricas
            if(y_ref == None):
                self.__y_ref = self.metricas_gerais.valor_media_alvo()
            else:
                self.__y_ref = y_ref
            
        else:
            self.__y_pred = None
            self.__y_ref = None
        
        self.__dict_valores = {}
        self.__dict_qtds = {}
        
        self.__dict_soma_alvo = {}
        self.__dict_media_alvo = {}
        self.__dict_desvio_norm = {}
        self.__dict_desvio_norm_por_bit = {}
        
        self.__dict_soma_pred = {}
        self.__dict_media_pred = {}
        self.__dict_metricas = {}
    
    def colunas_metricas_condicionais_prontas(self):
        return self.__dict_valores.keys()
    
    def calcula_metricas_condicionais(self, col_ref = []):
        num_linhas, _, colunas = self.distribuicoes.info_dataset()
        
        #Transforma uma string única em uma lista
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
        
        if(len(col_ref) != 0):
            colunas = col_ref
            
        for col_ref in colunas:
            flag_na = self.distribuicoes.retorna_flag_na(col_ref)
            valores = self.__df_tratado.loc[~flag_na, col_ref].astype(int).values
            y = self.__y[~flag_na]
            
            inds_ordenado = np.argsort(valores)
            valores_unico, primeira_ocorrencia, qtds = np.unique(valores[inds_ordenado], return_index = True, return_counts = True)
            self.__dict_valores[col_ref] = valores_unico
            self.__dict_qtds[col_ref] = qtds
            
            y_agrup = np.split(y[inds_ordenado], primeira_ocorrencia[1:])
            soma = np.array([np.sum(v) for v in y_agrup])
            self.__dict_soma_alvo[col_ref] = soma
            media = soma/qtds
            self.__dict_media_alvo[col_ref] = media
            
            #Ideia para ser o equivalente do Ganho de Informação
            desvio_ini = np.std(y)
            desvio_norm = np.std(media)/desvio_ini
            self.__dict_desvio_norm[col_ref] = desvio_norm
            qtd_unicos = valores_unico.size
            if(qtd_unicos > 1):
                self.__dict_desvio_norm_por_bit[col_ref] = desvio_norm/np.log2(qtd_unicos)
            else:
                self.__dict_desvio_norm_por_bit[col_ref] = 0
            
            if(self.__col_pred != None):
                y_pred = self.__y_pred[~flag_na]
                y_pred_agrup = np.split(y_pred[inds_ordenado], primeira_ocorrencia[1:])
                soma_pred = np.array([np.sum(v) for v in y_pred_agrup])
                self.__dict_soma_pred[col_ref] = soma_pred
                self.__dict_media_pred[col_ref] = soma_pred/qtds
                self.__dict_metricas[col_ref] = np.array([AletricasRegressao(y_agrup[i], y_pred_agrup[i], 
                                                          y_ref = self.__y_ref, num_kendalltau = self.__num_kendalltau) for i in range(valores_unico.size)])
                                                          
        #Ordena por Desvio
        self.__dict_desvio_norm = dict(reversed(sorted(self.__dict_desvio_norm.items(), key = lambda x: x[1])))
        self.__dict_desvio_norm_por_bit = dict(reversed(sorted(self.__dict_desvio_norm_por_bit.items(), key = lambda x: x[1])))
    
    def desvio_normalizado(self):
        return pd.Series(self.__dict_desvio_norm, index = self.__dict_desvio_norm.keys())

    def desvio_normalizado_por_bit(self):
        return pd.Series(self.__dict_desvio_norm_por_bit, index = self.__dict_desvio_norm_por_bit.keys())
    
    def valor_metricas_condicionais(self, col_ref):
        df = pd.DataFrame()
        if(col_ref in self.__dict_soma_alvo.keys()):
        
            df['Valores'] = self.__dict_valores[col_ref]
            if(col_ref in self.__dict_intervs.keys()):
                df['Labels'] = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            elif(col_ref in self.__dict_filtroscat.keys()):
                df['Labels'] = self.__dict_filtroscat[col_ref].strings_categorias()
            df['QTD'] = self.__dict_qtds[col_ref]
            df['Soma_Alvo'] = self.__dict_soma_alvo[col_ref]
            df['Media_Alvo'] = self.__dict_media_alvo[col_ref]
            
            if(self.__col_pred != None):
                df['Soma_Pred'] = self.__dict_soma_pred[col_ref]
                df['Media_Pred'] = self.__dict_media_pred[col_ref]
                df['Metricas'] = self.__dict_metricas[col_ref]
                df = pd.concat([df, df['Metricas'].apply(lambda x: x.valor_metricas(estatisticas_globais = False))], axis = 1)
                df = df.drop('Metricas', axis = 1)

        return df
    
    def curva_media_condicional(self, col_ref):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
        media_alvo = self.__dict_media_alvo[col_ref]
        if(self.__col_pred != None):
            media_pred = self.__dict_media_pred[col_ref]
        else:
            media_pred = None
            
        #Ordena por média do alvo se forem categorias (e podemos rearranjar a ordem)
        if(tipo == 'categoria'):
            inds_ordenado = np.argsort(media_alvo)
            valores = valores[inds_ordenado]
            labels = labels[inds_ordenado]
            media_alvo = media_alvo[inds_ordenado]
            if(self.__col_pred != None):
                media_pred = media_pred[inds_ordenado]
            
        return valores, labels, media_alvo, media_pred, tipo
    
    def curvas_metricas_condicionais(self, col_ref, metricas):
        valores = self.__dict_valores[col_ref]
        if(col_ref in self.__dict_intervs.keys()):
            labels = self.__dict_intervs[col_ref].strings_intervalos_discretizacao()
            tipo = 'intervalo'
        elif(col_ref in self.__dict_filtroscat.keys()):
            labels = self.__dict_filtroscat[col_ref].strings_categorias()
            tipo = 'categoria'
        else:
            labels = None
            tipo = None
            
        df = self.valor_metricas_condicionais(col_ref)            
        valores_metricas = []
        for metrica in metricas:
            valores_metricas.append(df[metrica].values)
            
        return valores, labels, valores_metricas, tipo
    
    def grafico_media_condicional(self, col_ref, ylim = [0, 0], figsize = [6, 4]):
        if(col_ref in self.__dict_soma_alvo.keys()):
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            
            #Plot a curva de probabilidade dada pelo Alvo e pela Prob do Classificador
            with sns.axes_style("whitegrid"):
                fig, axs = plt.subplots(1, 1, figsize = figsize)
                valores, labels, media_alvo, media_pred, tipo = self.curva_media_condicional(col_ref)
                desvio_norm = self.__dict_desvio_norm[col_ref]
                desvio_norm_por_bit = self.__dict_desvio_norm_por_bit[col_ref]
                if(labels is not None):
                    if(tipo == 'intervalo'):
                        axs.bar(valores, media_alvo, color = paleta_cores[0], label = 'Real')
                        axs.set_xticks(valores)
                        axs.set_xticklabels(labels, rotation = 90)
                        if(media_pred is not None):
                            axs.plot(valores, media_pred, color = paleta_cores[1], linewidth = 2, label = 'Regressor')
                    elif(tipo == 'categoria'):
                        axs.bar(labels, media_alvo, color = paleta_cores[0], label = 'Real')
                        if(media_pred is not None):
                            axs.plot(labels, media_pred, color = paleta_cores[1], linewidth = 2, label = 'Regressor')
                else:
                    if(conv_str):
                        valores = valores.astype(str)
                    axs.bar(valores, media_alvo, color = paleta_cores[0], label = 'Real')
                    if(media_pred is not None):
                        axs.plot(valores, media_pred, color = paleta_cores[1], linewidth = 2, label = 'Classificador')
                plt.gcf().text(1, 0.5, 'DESV = ' + '%.2g' % desvio_norm + '\n' + 'DESV/Bit = ' + '%.2g' % desvio_norm_por_bit, 
                               bbox = dict(facecolor = 'white', edgecolor = 'k', boxstyle = 'round'))
                axs.set_xlabel(col_ref)
                axs.set_ylabel('Média dos Valores')
                if(ylim[1] > ylim[0]):
                    axs.set_ylim(ylim)
                axs.legend(bbox_to_anchor=(1.15, 1), loc='upper left')
                plt.show()

    def grafico_metricas_condicionais(self, col_ref, metricas, conv_str = True, ylim = [0, 0], figsize = [6, 4]):
        if(col_ref in self.__dict_soma_alvo.keys()):
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            #Plot a curva de métrica em função da coluna de referência
            with sns.axes_style("whitegrid"):
                fig, axs = plt.subplots(1, 1, figsize = figsize)
                valores, labels, valores_metricas, tipo = self.curvas_metricas_condicionais(col_ref, metricas)
                for i in range(len(metricas)):
                    valores_metrica = valores_metricas[i]
                    if(labels is not None):
                        if(tipo == 'intervalo'):
                            if(valores.size > 1):
                                axs.plot(valores, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                            else:
                                axs.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                            axs.set_xticks(valores)
                            axs.set_xticklabels(labels, rotation = 90)
                        elif(tipo == 'categoria'):
                            if(valores.size > 1):
                                axs.plot(labels, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                            else:
                                axs.scatter(labels, valores_metrica, color = paleta_cores[i], label = metricas[i])
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        if(valores.size > 1):
                            axs.plot(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                        else:
                            axs.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                axs.set_xlabel(col_ref)
                axs.set_ylabel('Metricas')
                if(ylim[1] > ylim[0]):
                    axs.set_ylim(ylim)
                axs.legend(bbox_to_anchor=(1.15, 1), loc='upper left')
                plt.show()
                
##############################

##############################

class AvaliaDatasetsRegressao:

    def __init__(self, dict_dfs, col_alvo, col_pred = None, num_kendalltau = 10000, num_div = None, frac_cat = 0, chave_treino = 'Treino'):
        self.__dict_dfs = dict_dfs
        self.__num_dfs = len(dict_dfs)
        self.__chave_treino = chave_treino
        
        self.__dict_avaliargs = {}
        if(self.__chave_treino in self.__dict_dfs.keys()):
            avaliargs_treino = AvaliaRegressao(self.__dict_dfs[self.__chave_treino], col_alvo, col_pred, num_kendalltau = num_kendalltau, num_div = num_div, frac_cat = frac_cat)
            #Pega o y_ref do treino
            y_ref = avaliargs_treino.metricas_gerais.valor_media_alvo()
            self.__dict_avaliargs[self.__chave_treino] = avaliargs_treino
        for chave in self.__dict_dfs.keys():
            if(chave != self.__chave_treino):
                self.__dict_avaliargs[chave] = AvaliaRegressao(self.__dict_dfs[chave], col_alvo, col_pred, y_ref, num_kendalltau, num_div, frac_cat)
        
    def avaliadores_individuais(self):
        return self.__dict_avaliargs
        
    def calcula_metricas_condicionais(self, col_ref = []):
        for chave in self.__dict_dfs.keys():
            self.__dict_avaliargs[chave].calcula_metricas_condicionais(col_ref)
    
    def valor_metricas(self, estatisticas_globais = True, metricas_ref = True, alga_signif = 0, conv_str = False):
        df = pd.DataFrame(self.__dict_avaliargs[self.__chave_treino].metricas_gerais.valor_metricas(estatisticas_globais, metricas_ref, alga_signif, conv_str), columns = [self.__chave_treino])
        for chave in self.__dict_dfs.keys():
            if(chave != self.__chave_treino):
                df[chave] = self.__dict_avaliargs[chave].metricas_gerais.valor_metricas(estatisticas_globais, metricas_ref, alga_signif, conv_str)
        return df
                
    def grafico_distribuicao(self, col_ref = [], conv_str = True, figsize = [6, 4]):
        _, _, colunas = self.__dict_avaliaclf[self.__chave_treino].distribuicoes.info_dataset()
    
        #Transforma uma string única em uma lista
        if(isinstance(col_ref, str)):
            col_ref = [col_ref]
    
        if(len(col_ref) != 0):
            colunas = col_ref
            
        for col_ref in colunas:
            if(col_ref in self.__dict_avaliaclf[self.__chave_treino].colunas_metricas_condicionais_prontas()):
                paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
                
                #Plota informações da distribuição da variável de referência nos dados
                with sns.axes_style("whitegrid"):
                    fig, axs = plt.subplots(1, 1, figsize = figsize)
                    i = 0
                    for chave in self.__dict_dfs.keys():
                        valores, frac, tipo = self.__dict_avaliaclf[chave].distribuicoes.curva_distribuicao(col_ref)
                        if(tipo == 'intervalo'):
                            axs.fill_between(valores, frac, color = paleta_cores[i], alpha = 0.5)
                            axs.plot(valores, frac, color = paleta_cores[i], label = chave)
                            axs.set_ylabel('Fração/L')
                        elif(tipo == 'categoria'):
                            axs.bar(valores, frac, color = paleta_cores[i], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[i], label = chave)
                            axs.set_ylabel('Fração')
                        else:
                            if(conv_str):
                                valores = valores.astype(str)
                            axs.bar(valores, frac, color = paleta_cores[i], alpha = 0.5, width = 1, linewidth = 3, edgecolor = paleta_cores[i], label = chave)
                            axs.set_ylabel('Fração')
                        i = i + 1
                    axs.set_xlabel(col_ref)
                    axs.set_ylim(bottom = 0.0)
                    axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                    plt.show()
                
    def grafico_media_condicional(self, col_ref, ylim = [0, 0], figsize_base = [6, 4]):
        if(col_ref in self.__dict_avaliargs[self.__chave_treino].colunas_metricas_condicionais_prontas()):
        
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            
            #Plot a curva de probabilidade dada pelo Alvo e pela Prob do Classificador
            with sns.axes_style("whitegrid"):
                if(ylim[1] > ylim[0]):
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]], 
                                            sharex = True, sharey = True)
                    plt.subplots_adjust(wspace = 0.01)
                else:
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]])
                i = 0
                hlds = []
                for chave in self.__dict_dfs.keys():
                    if(self.__num_dfs > 1):
                        ax = axs[i]
                    else:
                        ax = axs
                        
                    valores, labels, media_alvo, media_pred, tipo = self.__dict_avaliargs[chave].curva_media_condicional(col_ref)
                    
                    if(labels is not None):
                        if(tipo == 'intervalo'):
                            ax.bar(valores, media_alvo, color = paleta_cores[i], label = chave)
                            ax.set_xticks(valores)
                            ax.set_xticklabels(labels, rotation = 90)
                            if(media_pred is not None):
                                if(valores.size > 1):
                                    ax.plot(valores, media_pred, color = 'black', linewidth = 2)
                                else:
                                    ax.scatter(valores, media_pred, color = 'black', label = 'Regressor')
                        elif(tipo == 'categoria'):
                            ax.bar(labels, media_alvo, color = paleta_cores[i], label = chave)
                            if(media_pred is not None):
                                if(valores.size > 1):
                                    ax.plot(labels, media_pred, color = 'black', linewidth = 2)
                                else:
                                    ax.scatter(labels, media_pred, color = 'black')
                    else:
                        if(conv_str):
                            valores = valores.astype(str)
                        ax.bar(valores, media_alvo, color = paleta_cores[i], label = chave)
                        if(media_pred is not None):
                            if(valores.size > 1):
                                ax.plot(valores, media_pred, color = 'black', linewidth = 2)
                            else:
                                ax.scatter(valores, media_pred, color = 'black')
                        
                    if(ylim[1] > ylim[0]):
                        ax.set_ylim(ylim)
                        if(i == 0):
                            ax.set_xlabel(col_ref)
                            ax.set_ylabel('Média dos Valores')
                    else:
                        ax.set_xlabel(col_ref)
                        ax.set_ylabel('Média dos Valores')
                    ax.set_title(chave)
                    hlds.append(mpl.patches.Patch(color = paleta_cores[i], label = chave))
                    i = i + 1
                hlds.append(mpl.patches.Patch(color = 'k', label = 'Regressor'))
                plt.legend(handles = hlds, bbox_to_anchor = (1.3, 1), loc = 'upper left')
                plt.show()
                
    def grafico_metricas_condicionais(self, col_ref, metricas, ylim = [0, 0], conv_str = True, figsize_base = [6, 4]):
        if(col_ref in self.__dict_avaliargs[self.__chave_treino].colunas_metricas_condicionais_prontas()):
            paleta_cores = sns.color_palette("colorblind") #Paleta de cores para daltonico
            with sns.axes_style("whitegrid"):
                if(ylim[1] > ylim[0]):
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]], 
                                            sharex = True, sharey = True)
                    plt.subplots_adjust(wspace = 0.01)
                else:
                    fig, axs = plt.subplots(1, self.__num_dfs, figsize = [figsize_base[0]*self.__num_dfs, figsize_base[1]])
                j = 0
                hlds = []
                for chave in self.__dict_dfs.keys():
                    if(self.__num_dfs > 1):
                        ax = axs[j]
                    else:
                        ax = axs

                    valores, labels, valores_metricas, tipo = self.__dict_avaliargs[chave].curvas_metricas_condicionais(col_ref, metricas)
                    for i in range(len(metricas)):
                        valores_metrica = valores_metricas[i]
                        if(labels is not None):
                            if(tipo == 'intervalo'):
                                if(valores.size > 1):
                                    ax.plot(valores, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                                else:
                                    ax.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                                ax.set_xticks(valores)
                                ax.set_xticklabels(labels, rotation = 90)
                            elif(tipo == 'categoria'):
                                if(valores.size > 1):
                                    ax.plot(labels, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                                else:
                                    ax.scatter(labels, valores_metrica, color = paleta_cores[i], label = metricas[i])
                        else:
                            if(conv_str):
                                valores = valores.astype(str)
                            if(valores.size > 1):
                                ax.plot(valores, valores_metrica, color = paleta_cores[i], linewidth = 2, label = metricas[i])
                            else:
                                ax.scatter(valores, valores_metrica, color = paleta_cores[i], label = metricas[i])
                                    
                        if(chave == self.__chave_treino):
                            hlds.append(mpl.patches.Patch(color = paleta_cores[i], label = metricas[i]))
                    
                    if(ylim[1] > ylim[0]):
                        ax.set_ylim(ylim)
                        if(j == 0):
                            ax.set_xlabel(col_ref)
                            ax.set_ylabel('Metricas')
                    else:
                        ax.set_xlabel(col_ref)
                        ax.set_ylabel('Metricas')
                    ax.set_title(chave)
                    j = j + 1
                plt.legend(handles = hlds, bbox_to_anchor = (1.3, 1), loc = 'upper left')
                plt.show()
                
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns

class TaylorBoostRegressor:
    
    def __init__(self, grau_max = 2, max_termos = None, passo = 1,
                 alph_eps = [0.1, 0.1], gpu = False, n_jobs = None):
        self.__grau_max = grau_max
        self.__max_termos = max_termos
        self.__passo = passo
        if isinstance(alph_eps, list):
            self.__alpha = alph_eps[0]
            self.__epsilon = alph_eps[1]
        else:
            self.__alpha = None
            self.__epsilon = None
        self.__gpu = gpu
        self.__n_jobs = n_jobs
        if(self.__gpu):
            import cupy as cp #pip install cupy-cuda112
            self.__mempool = cp.get_default_memory_pool()
            self.__pinned_mempool = cp.get_default_pinned_memory_pool()
        
        #OBS: Note que por conta do epsilon e do alpha, dados normalizados são melhores de otimizar
        #E assim mais fácil de rodar o algoritmo
    
    def __limpa_memoria_gpu(self):
        self.__mempool.free_all_blocks()
        self.__pinned_mempool.free_all_blocks()  
    
    def __checa_X_predict(self, X):
        if isinstance(X, pd.DataFrame):
            X = X.values
        else:
            try:
                if len(X.shape) != 2:
                    print("Valores de entrada de predição não adequados")
                    return
            except:
                print("Valores de entrada de predição não adequados")
                return
        return X
    
    def __checa_X_e_y_treino(self, X, y):
        if isinstance(X, pd.DataFrame):
            self.__X = X.values
            self.__nome_vars = X.columns.values
        else:
            try:
                if len(X.shape) == 2:
                    self.__X = X
                else:
                    print("Valores de entrada de treino não adequados")
                    return
            except:
                print("Valores de entrada de treino não adequados")
                return
        self.__num_linhas = self.__X.shape[0]
        self.__num_cols = self.__X.shape[1]
        
        if (isinstance(y, pd.DataFrame) and len(y.columns) == 1) or (isinstance(y, pd.Series)):
            self.__y = y.values
        else:
            try:
                if len(y.shape) == 1:
                    self.__y = y
                else:
                    print("Valores de alvo de treino não adequados")
                    return
            except:
                print("Valores de alvo de treino não adequados")
                return
        if(self.__y.size != self.__num_linhas):
            print("Quantidade de exemplos não coindicem em X e y")
            return
            
    def __checa_conjunto_validacao(self, conj_val):
        #Verifica se foi passado um conjunto de validação
        if conj_val != None:
            if isinstance(conj_val, tuple):
                if(len(conj_val) == 2):
                    if isinstance(conj_val[0], pd.DataFrame):
                        self.__Xval = conj_val[0].values
                    else:
                        try:
                            if len(conj_val[0].shape) == 2:
                                self.__Xval = conj_val[0]
                            else:
                                print("Valores de entrada de validação não adequados")
                                return
                        except:
                            print("Valores de entrada não adequados")
                            return
                        
                    if (isinstance(conj_val[1], pd.DataFrame) and len(conj_val[1].columns) == 1) or (isinstance(conj_val[1], pd.Series)):
                        self.__yval = conj_val[1].values
                    else:
                        try:
                            if len(conj_val[1].shape) == 1:
                                self.__yval = conj_val[1]
                            else:
                                print("Valores de alvo de validação não adequados")
                                return
                        except:
                            print("Valores de alvo de validação não adequados")
                            return
                        
                else:
                    print("Valores de validação não adequados")
                    return
            else:
                print("Valores de validação não adequados")
                return
            self.__tem_validacao = True
        else:
            self.__tem_validacao = False
    
    def __guarda_melhor_modelo(self, r2_val):
        #Guarda o modelo atual nas variáveis de melhor modelo
        self.__vars_selec_melhor = self.__vars_selec
        self.__num_termos_melhor = self.__num_termos
        self.__y_pred_melhor = self.__y_pred
        self.__diff_melhor = self.__diff
        self.__thetas_melhor = self.__thetas
        self.__gradiente_melhor = self.__gradiente
        self.__r2_val_melhor = r2_val      
        
    def __calcula_r2(self, diff, mse_baseline):
        if(self.__gpu):
            r2 = 1 - float(cp.mean(diff**2))/mse_baseline
        else:
            r2 = 1 - np.mean(diff**2)/mse_baseline
        return r2
    
    def __calcula_predicoes(self, thetas, X):
        if(self.__gpu):
            self.__limpa_memoria_gpu()
            y_pred = thetas[0] + cp.dot(X, cp.array(thetas[1:]))
        else:
            y_pred = thetas[0] + np.dot(X, thetas[1:])
        return y_pred
        
    def __derivada_parcial_custo(self, diff, vetor_x):
        #Implementa o calculo da derivada parcial da função de custo
        if(self.__gpu):
            return float(cp.sum(diff*vetor_x)/diff.size)
        else:
            return np.sum(diff*vetor_x)/diff.size
    
    def __ajusta_predicoes(self, vars_der_add, thetas_add):
        if(self.__gpu):
            self.__limpa_memoria_gpu()
            yn_pred_add = cp.dot(self.__X[:, vars_der_add], cp.array(thetas_add))
            self.__y_pred = self.__y_pred + yn_pred_add #Muda as predições com os novos thethas
        else:
            yn_pred_add = np.dot(self.__X[:, vars_der_add], thetas_add)
            self.__y_pred = self.__y_pred + yn_pred_add #Muda as predições com os novos thethas
    
    def __calcula_derivadas(self):
        if(self.__gpu):
            der_parciais = np.array([float(cp.mean(self.__diff))]) #Derivada parcial do termo theta_0
            der_parciais_resto = np.array([self.__derivada_parcial_custo(self.__diff, self.__X[:, v]) 
                                           for v in self.__vars_selec])
            der_parciais = np.append(der_parciais, der_parciais_resto)
        else:
            der_parciais = np.array([np.mean(self.__diff)]) #Derivada parcial do termo theta_0
            der_parciais_resto = np.array([self.__derivada_parcial_custo(self.__diff, self.__X[:, v]) 
                                           for v in self.__vars_selec])
            der_parciais = np.append(der_parciais, der_parciais_resto)
        return der_parciais
    
    def __descida_gradiente(self, derivadas_add, vars_der_add):
        alpha = self.__alpha
        gradiente_referencia = (self.__gradiente**2 + np.sum(derivadas_add**2))**0.5
        #Calcula o gradiente que aparece a mais só por considerarmos esse termo a mais
        #mesmo se considerarmos o valor do seu coeficiente como zero (referencia para alterar alpha)
    
        #Passo Zero
        thetas_add = -alpha * derivadas_add
        self.__thetas = np.append(self.__thetas, thetas_add) #Adiciona os novos thetas
        self.__ajusta_predicoes(vars_der_add, thetas_add)
        self.__diff = self.__y_pred - self.__y #Calcula as diferenças entre predito e label
        der_parciais = self.__calcula_derivadas()
        self.__gradiente = np.sum(der_parciais**2)**0.5
        if(self.__gradiente > gradiente_referencia):
            alpha = alpha/2 #Diminui o alpha se o passo foi muito grande: aumentou o gradiente
        else:
            alpha = self.__alpha
            gradiente_referencia = self.__gradiente
    
        #Loop de outros passos até a convengência exigida: isto é, o valor epsilon
        while(self.__gradiente >= self.__epsilon):
            self.__thetas = self.__thetas - alpha * der_parciais #Adiciona os novos thetas
            self.__y_pred = self.__calcula_predicoes(self.__thetas, self.__X[:, self.__vars_selec])
            self.__diff = self.__y_pred - self.__y #Calcula as diferenças entre predito e label
            der_parciais = self.__calcula_derivadas()
            self.__gradiente = np.sum(der_parciais**2)**0.5
            if(self.__gradiente > gradiente_referencia):
                alpha = alpha/2 #Diminui o alpha se o passo foi muito grande: aumentou o gradiente
            else:
                alpha = self.__alpha
                gradiente_referencia = self.__gradiente
    
    def fit(self, X, y, conj_val = None, nome_vars = None):
        self.__nome_vars = nome_vars
        self.__checa_X_e_y_treino(X, y)
        self.__checa_conjunto_validacao(conj_val)
        
        #Gera os termos polinomiais nos dados
        if(self.__grau_max > 1):
            self.__exp_taylor = PolynomialFeatures(degree = self.__grau_max, include_bias = False)
            self.__exp_taylor = self.__exp_taylor.fit(self.__X)
            self.__X = self.__exp_taylor.transform(self.__X)
            if(self.__tem_validacao):
                self.__Xval = self.__exp_taylor.transform(self.__Xval)
        
        #Faz a normalização
        #Facilita calculo de Inv. de Matriz e também facilita a Descida do Gradiente
        self.__means = np.mean(self.__X, axis = 0)
        self.__stds = np.mean((self.__X - self.__means)**2, axis = 0)**0.5
        self.__stds = np.array([v if v > 0 else 1 for v in self.__stds]) #Quando o desvio padrão é 0 
        self.__X = (self.__X - self.__means)/self.__stds
        if(self.__tem_validacao):
            self.__Xval = (self.__Xval - self.__means)/self.__stds
        
        #Normaliza o y também: acho que ajuda na Descida do Gradiente
        self.__media_y = np.mean(self.__y)
        self.__desvio_y = np.mean((self.__y - self.__media_y)**2)**0.5
        self.__y = (self.__y - self.__media_y)/self.__desvio_y
        if(self.__tem_validacao):
            self.__yval = (self.__yval - self.__media_y)/self.__desvio_y
        
        #Faz o modelo baseline: só o termo theta_0 -> cte!
        self.__vars_selec = np.array([]).astype(int) #Lista das variaveis selecionadas no regressor
        self.__num_termos = 1 #Número de termos do regressor
        self.__y_pred = np.repeat(np.mean(self.__y), self.__y.size) #predição do baseline
        self.__diff = self.__y_pred - self.__y #Diferenças entre o real e o predito
        self.__thetas = np.array([self.__y_pred[0]]) #Valor dos thetas do regressor
        self.__gradiente = 0 #No caso o gradiente é zero pq foi o mínimo exato
        
        #Salva o mse do modelo baseline (só constante)
        self.__mse_baseline = np.mean(self.__diff**2)
        if(self.__tem_validacao):
            self.__mse_baseline_val = np.mean((self.__yval - self.__thetas[0])**2)
        
        #####
        ##### Algoritmo em loop incremental estilo Boosting para aumentar a complexidade #####
        #####
        
        #Converte para fazer as contas mais pesadas em GPU
        if(self.__gpu and self.__epsilon != None):
            self.__limpa_memoria_gpu()
            self.__X = cp.array(self.__X)
            self.__y = cp.array(self.__y)
            if(self.__tem_validacao):
                self.__Xval = cp.array(self.__Xval)
                self.__yval = cp.array(self.__yval)
            self.__y_pred = cp.array(self.__y_pred)
            self.__y_pred = cp.array(self.__y_pred)
            self.__diff = cp.array(self.__diff)
        
        #Inicializamos as variaveis para criar a curva viés-variância
        self.__curva_num_termos = np.array([self.__num_termos])
        self.__curva_r2 = np.array([0])
        if(self.__tem_validacao):
            self.__curva_r2_val = np.array([0])
            self.__guarda_melhor_modelo(0)
            
        vars_disp = np.arange(self.__X.shape[1]) #vetor com as variaveis disponíveis para escolher
        if(self.__max_termos == None):
            self.__max_termos = vars_disp.size + 1 #Considera todos os termos se não tiver dado limite
        else:
            self.__max_termos = min(self.__max_termos, vars_disp.size + 1)

        #Loop do processo incremental de adição de termos na regressão
        while(self.__num_termos < self.__max_termos and vars_disp.size > 0):
            #Calcula todos valores das derividas parciais dos termos que estão faltando na regressão
            derivadas_parciais = np.array([self.__derivada_parcial_custo(self.__diff, self.__X[:, v]) 
                                           for v in vars_disp])
            derivadas_parciais_abs = np.abs(derivadas_parciais) #Pega os valores da derivada em módulo
            inds_ordena_derivadas = np.argsort(derivadas_parciais_abs)[::-1] #Ordena decrescente
            pos_der_add = inds_ordena_derivadas[:min(self.__passo, vars_disp.size)]
            vars_der_add = vars_disp[pos_der_add] #Lista das respectivas vars
            #Adiciona essas variaveis no regressor: Note que o passo define quantas vars add por vez
            self.__vars_selec = np.append(self.__vars_selec, vars_der_add)
            self.__num_termos = self.__num_termos + self.__passo
            vars_disp = np.delete(vars_disp, pos_der_add) #Remove essas variaveis das disponíveis
            #Isto é, a ideia aqui foi incrementar o regressor com a variável que mais vai "bagunçar"
            # o mínimo que já haviamos encontrado para a Função de Custo: ou seja, deriv. parcial max.
            
            if(self.__epsilon == None):
                #Resolve analiticamente (solução exata)
                reg = LinearRegression(n_jobs = self.__n_jobs).fit(self.__X[:, self.__vars_selec], 
                                                                   self.__y)
                self.__y_pred = reg.predict(self.__X[:, self.__vars_selec])
                self.__diff = self.__y_pred - self.__y #Diferenças entre o real e o predito
                self.__thetas = np.insert(reg.coef_, 0, reg.intercept_)
                self.__gradiente = 0
            else:
                ###### Otimiza os thetas pelo algoritmo de Descida do Gradiente ######
                self.__descida_gradiente(derivadas_parciais[pos_der_add], vars_der_add)
            
            #Calcula os MSE e adiciona na curva de Viés-Variância
            self.__curva_num_termos = np.append(self.__curva_num_termos, self.__num_termos)
            r2 = self.__calcula_r2(self.__diff, self.__mse_baseline)
            self.__curva_r2 = np.append(self.__curva_r2, r2)
            if(self.__tem_validacao):
                yval_pred = self.__calcula_predicoes(self.__thetas, self.__Xval[:,self.__vars_selec])
                diff_val = yval_pred - self.__yval
                r2_val = self.__calcula_r2(diff_val, self.__mse_baseline_val)
                self.__curva_r2_val = np.append(self.__curva_r2_val, r2_val)
                #Vê se encontramos um novo melhor modelo e guarda ele
                if(r2_val > self.__r2_val_melhor):
                    self.__guarda_melhor_modelo(r2_val)
                
                print(str(r2) + " / " + str(r2_val) + " (" + str(self.__num_termos_melhor) + ")")
            else:
                print(str(r2) + " (" + str(self.__num_termos) + ")")
        
        if(self.__gpu and self.__epsilon != None):
            self.__X = cp.asnumpy(self.__X)
            self.__limpa_memoria_gpu()
        
        #####
        ##### Fim do loop do algoritmo incremental #####
        #####
        
        #Calcula importancias das variáveis selecionadas e pega seus nomes nas expansão de taylor
        self.__calcula_importancias()
        self.__traduz_nomes_vars()
        
    def predict(self, X):
        X = self.__checa_X_predict( X)
        if(self.__grau_max > 1):
            X = self.__exp_taylor.transform(X)
        X = (X - self.__means)/self.__stds
        if(self.__tem_validacao):
            y_pred = self.__thetas_melhor[0] + np.dot(X[:, self.__vars_selec_melhor],
                                                      self.__thetas_melhor[1:])
        else:
            y_pred = self.__thetas[0] + np.dot(X[:, self.__vars_selec], self.__thetas[1:])
        y_pred = self.__media_y + self.__desvio_y*y_pred 
        return y_pred
    
    def grafico_vies_variancia(self, pos_ini = None, pos_fim = None, figsize = [8, 6]):        
        #Prepara os valores e vetores de plot
        if(pos_ini == None):
            pos_ini = 0
        if(pos_fim == None):
            pos_fim = self.__curva_num_termos.size
        curva_num_termos = self.__curva_num_termos[pos_ini:pos_fim]
        curva_r2 = self.__curva_r2[pos_ini:pos_fim]
        if(self.__tem_validacao):
            curva_r2_val = self.__curva_r2_val[pos_ini:pos_fim]
            r2_val_melhor = self.__r2_val_melhor
            r2_min = min(min(curva_r2), min(curva_r2_val))
        #Plota as curvas e o ponto de parada do treinamento pela validação
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            axs.plot(curva_num_termos, curva_r2, color = paleta_cores[0], label = 'Treino')
            if(self.__tem_validacao):
                axs.plot(curva_num_termos, curva_r2_val, color = paleta_cores[1], label = 'Validação')
                axs.vlines(self.__num_termos_melhor, r2_min, r2_val_melhor, color = 'k', 
                           linestyle = '--', label = 'Ponto de Parada')
            axs.set_xlabel('Número de Termos')
            axs.set_ylabel('R2')
            axs.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.show()

    def __calcula_importancias(self):
        if(self.__tem_validacao):
            vars_selec = self.__vars_selec_melhor
            thetas = self.__thetas_melhor
        else:
            vars_selec = self.__vars_selec
            thetas = self.__thetas
        if(self.__grau_max > 1):
            nomes_vars = np.array(self.__exp_taylor.get_feature_names())
        else:
            nomes_vars = np.array(['x'  + str(i) for i in range(0, self.__num_cols)])
        self.feature_names_ = np.array([nomes_vars[v] for v in vars_selec])
        coef_abs = np.abs(thetas[1:])
        self.feature_importances_ = coef_abs/np.sum(coef_abs)
    
    def __traduz_nomes_vars(self):
        if(isinstance(self.__nome_vars, np.ndarray)):
            chaves = ['x' + str(i) for i in range(self.__nome_vars.size)]
            dic_vars = dict(zip(chaves[::-1], self.__nome_vars[::-1]))
            def trocar(string, dic_vars):
                for chave, valor in dic_vars.items():
                    string = string.replace(chave, valor)
                return string
            self.feature_names_ = np.array([trocar(s, dic_vars) for s in self.feature_names_])
            
    def grafico_importancias(self, num_vars = None, figsize = [8, 6]):        
        if(num_vars == None):
            num_vars = self.__curva_num_termos.size
        vars_nomes = self.feature_names_
        vars_imp = self.feature_importances_
        inds_ordenado = np.argsort(vars_imp)[::-1]
        vars_nomes = vars_nomes[inds_ordenado[:num_vars]]
        vars_imp = vars_imp[inds_ordenado[:num_vars]]
        paleta_cores = sns.color_palette("colorblind")
        with sns.axes_style("whitegrid"):
            fig, axs = plt.subplots(1, 1, figsize = figsize)
            axs.barh(vars_nomes[::-1], vars_imp[::-1], color = paleta_cores[0])
            axs.set_xlabel('Importância')
            axs.set_ylabel('Variável')
            plt.show()
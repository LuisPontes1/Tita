from datetime import datetime
import dateutil

def janelasMoveisDF(data,df):
    
    #DF de entrada -> Verificar maneira de o DF de entrada ter a chave e a data em formato mes_ref (2020-01-01 / 2020-02-01)
    df_teste = df
    
    #data = '20181231'
    
    lista_janela = [12,6,3] # Janelas de meses a serem processadas a partir da data selecionada para processamento ### MANTER DECRESCENTE
    datas_janela = [] #datas que serão calculadas pelos loops
    
    #Ajuste da string
    
    data_date = datetime.strptime(data,'%Y%m%d')
    data_date = data_date.strftime('%Y%m')
    data_date = datetime.strptime(data_date,'%Y%m')
    
    #Janela de calculo das datas 
    
    for window in lista_janela:
        data_delta = data_date - dateutil.relativedelta.relativedelta(months=window)
        datas_janela.append(data_delta.strftime('%Y-%m-%d'))
    data_date = data_date.strftime('%Y-%m-%d')
    
    #Separação de 12 meses a partir da data de processamento <- m-12
    
    df_full = df_teste[(df_teste['DT_REF'] >= datas_janela[0]) & (df_teste['DT_REF'] <= data_date)]
    df_left = df_teste[df_teste['DT_REF'] == data_date]
    
    #Chaves da Tabela e Lista de variáveis de agregação a serem calculadas
    
    lista_chave = ['pk_numdoc', 'DT_REF']
    lista_agg = ['min', 'max','mean','median','std']
    
    #Separa DF da esquerda com nivel analitico do mes
    
    df_left = df_left[lista_chave]
    
    #Loop de agregação dentro de cada janela
    
    for jnl in range(0,len(lista_janela)):
        janela = str(lista_janela[jnl])
        
        #Recorta a janela temporal dentro do espaço de 12 meses
        
        df_agg = df_full[(df_full['DT_REF'] >= datas_janela[jnl]) & (df_full['DT_REF'] <= data_date)]
        
        #Separa a quantidade de meses que o documento aparece dentro da janela...determinando assim se ele está completo na janela.
        
        df_agg_count = df_agg[lista_chave]
        df_filtro = df_agg_count.groupby('pk_numdoc').agg('count').reset_index()
        df_filtro.rename(columns={"DT_REF": "QTD_MESES"}, inplace=True)
        
        #Calcula as agregações
        
        pub_janela = df_agg.groupby('pk_numdoc').agg(lista_agg) #Aqui pode demorar um bocado
        
        #Ajusta o nome das colunas -> retirando o MultiIndex do nome das colunas (for na matriz de coluna)
        
        lista_colunas = []
        xx = len(pub_janela.columns)
        for x in range(0,xx):
            x = pub_janela.columns[x][0] + '_' + str(janela) + 'm'  + '_' + pub_janela.columns[x][1]
            lista_colunas.append(x)
        pub_janela.columns = lista_colunas
        pub_janela = pub_janela.reset_index()
        
        #Join das variaveis de janela com a quantidade de meses e marcação da Flag se documento está totalmente na janela ou n.
        
        df_janela = pd.merge(pub_janela,df_filtro,on='pk_numdoc',how='left')
        nome_var_flag = 'fl_sem_'+janela+'m'
        df_janela[nome_var_flag] = np.where(df_janela['QTD_MESES'] < int(janela), 1, 0)
        df_janela = df_janela.drop('QTD_MESES' , axis = 1)
        
        #Join juntando o publico da referencia tratada e das variaveis e flags realizadas
        
        df_left = pd.merge(df_left,df_janela,on='pk_numdoc',how='left')
        
    return df_left
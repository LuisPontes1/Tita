# -*- coding: utf-8 -*-
"""
Created on Fri May 28 12:13:11 2021

@author: lmontesanti
"""
import nltk
#nltk.set_proxy('http://usr:pass@10.234.198.25:8080')
#nltk.download('stopwords')

import nilc as nlc
import pandas as pd
import unicodedata
import re

from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator

import matplotlib.pyplot as plt

import numpy as np

from collections import Counter
from scipy.spatial.distance import cdist

from sklearn.cluster import KMeans
from sklearn import metrics
from sklearn import preprocessing
#a = nlc.clean_text('A cabra voadoa do Ivan tem 6 pes')

#%%

def removerAcentosECaracteresEspeciais(palavra):

    # Unicode normalize transforma um caracter em seu equivalente em latin.
    nfkd = unicodedata.normalize('NFKD', palavra)
    palavraSemAcento = u"".join([c for c in nfkd if not unicodedata.combining(c)])

    # Usa expressão regular para retornar a palavra apenas com números, letras e espaço
    return re.sub('[^a-zA-Z0-9 \\\]', '', palavraSemAcento)
    

def RemoveStopWords(sentence):
    stopwords = nltk.corpus.stopwords.words('portuguese')
    phrase = []
    for word in sentence.split(' '):
        if word not in stopwords:
            phrase.append(word)
    return " ".join(str(x) for x in phrase)

def removeNumero(sentence):
    sentence = sentence.replace('0', '')
    return sentence

def removeFrasesPequenas(df, col, qtd_palavras):
    df[col] = df[col].replace('\s+', ' ', regex=True)
    df[col] = df[df[col].str.len() > qtd_palavras]
    return df

def removeTermosDiferenciados(sentence):
    
    sentence = sentence.replace('0', '')
    
    baned_list = [
        #'nao', 
        'tambem', 'ter', 'ainda', 'ver',
                  'sao', 'ficou', 'apenas', 'b', 'exemplo',
                  'tipo', 'pois', 'ser', 'poderia', 'estao',
                  'bem', 'ja', 'informacoes', 'achei', 'porem',
                  'toda', 'parte'] # lista de palavras banidas
    phrase = []
    for word in sentence.split(' '):
        if word not in baned_list:
            phrase.append(word)
    return " ".join(str(x) for x in phrase)

def Tokenize(sentence):
    sentence = sentence.lower()
    sentence = nltk.word_tokenize(sentence)
    return sentence



#%%
def listaTipoCol(df, lista_chave):
    lista_colunas = df.columns.tolist()
    lista_str = []
    lista_num = []
    for var in lista_colunas:
        x = df[var].dtypes
        if x == 'object' and var not in lista_chave:
            lista_str.append(var)
        if (x == 'float64' or x == 'int64') and var not in lista_chave:
            lista_num.append(var)  
        #print(f"a variavel {var} é do tipo: {x}")
    return lista_str, lista_num


def aplic_cluster_n(base_model,qtd_clusters,var_resp, base_saida):
    kmeanModel = KMeans(n_clusters=qtd_clusters).fit(base_model)
    y = kmeanModel.predict(base_model)
    base_saida[var_resp] = y
    return base_saida

def cluster_n(X, qtd_clusters, var_ref, df_origem, modelo):
    base_model = X.copy()
    kmeanModel = KMeans(n_clusters=qtd_clusters).fit(base_model)
    y = kmeanModel.predict(base_model)
    base_model['resp'] = y
    base_model['resp'].value_counts()
    df_teste = df_origem[df_origem['DT_BALANCO'] == '2019-12-31'][var_ref]
    df_teste.head()
    df_final = pd.merge(base_model, df_teste, left_index=True, right_index=True)
    df_qtd_setor = df_final[var_ref].value_counts().reset_index()
    df_qtd_setor.columns = ['setor', 'qtd_setor']

    resp_list = df_final['resp'].unique()
    resp_list.sort()
    
    print(f'Este é total de empresas por cluster\n')
    display(base_model['resp'].value_counts())
    print(f'\n')
    print(f'Esta é a distribuição do percentual de {var_ref} dentro de cada cluster')

    for resp in resp_list:
        a = df_final[df_final['resp'] == resp]
        a[var_ref].value_counts(normalize=True).sort_index(ascending=False).plot.barh(title=f'Esse é o cluster {resp}')

        #orderanr por ordem alfabetica 

        plt.show()
    
    print(f'Esta é a distribuição do percentual de {var_ref} presente em cada cluster')
    
    for resp in resp_list:
        a = df_final[df_final['resp'] == resp]
        a = a[var_ref].value_counts().reset_index()
        a.columns = ['setor', 'setor_count']

        a = a.merge(df_qtd_setor, on='setor', how='left')

        a['percentage'] = a['setor_count']/a['qtd_setor']

        a.sort_values('setor', ascending=False).plot.barh(x='setor', y='percentage', title=f'Esse é o cluster {resp}')


        plt.show()
    
    pickle.dump(kmeanModel, open(modelo, 'wb')) #Saving the model
        
def eubou_metodo(X,max_K): #X = DF de entrada
    distortions = []
    inertias = []
    mapping1 = {}
    mapping2 = {}
    K = range(1, max_K)

    for k in K:
        # Building and fitting the model
        kmeanModel = KMeans(n_clusters=k).fit(X)
        kmeanModel.fit(X)

        distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_,
                                            'euclidean'), axis=1)) / X.shape[0])
        inertias.append(kmeanModel.inertia_)

        mapping1[k] = sum(np.min(cdist(X, kmeanModel.cluster_centers_,
                                       'euclidean'), axis=1)) / X.shape[0]
        mapping2[k] = kmeanModel.inertia_

    plt.plot(K, distortions, 'bx-')
    plt.xlabel('Values of K')
    plt.ylabel('Distortion')
    plt.title('The Elbow Method using Distortion')
    plt.show()

    plt.plot(K, inertias, 'bx-')
    plt.xlabel('Values of K')
    plt.ylabel('Inertia')
    plt.title('The Elbow Method using Inertia')
    plt.show()

    for key, val in mapping1.items():
        print(f'{key} : {val}')

def trata_base(df_teste):
    lista_1 = limpaNull(df_teste,5,0.1)
    df_teste_1 = df_teste[lista_1].copy()
    lista_str, lista_num = listaTipoCol(df_teste_1,lista_chave)
    df_teste_drop = df_teste_1[lista_num].copy()
    df_teste_drop = ajustaPercentil(df_teste_drop,0.05,0.95)
    df_teste_drop = df_teste_drop.fillna(-999)
    #scaler = preprocessing.StandardScaler()
    scaler = preprocessing.MinMaxScaler()
    #lista_colunas_teste = df_teste_drop.columns.tolist()
    df_teste_drop[lista_num] = scaler.fit_transform(df_teste_drop[lista_num])
    return df_teste_drop





#%%

df = pd.read_excel('dataset.xlsx')

#limpar nulos
df = df[df['txt'].notna()]

df['txt_clean'] = df['txt'].astype(str).apply(nlc.clean_text)
df['txt_clean'] = df['txt_clean'].apply(removerAcentosECaracteresEspeciais)

df['txt_clean'] = df['txt_clean'].apply(RemoveStopWords)

df['txt_clean'] = df['txt_clean'].apply(removeNumero)
df = df[df['txt_clean'].isnull() == False]
#df = removeFrasesPequenas(df, 'txt_clean', 1)

#apenas no wordcloud
#df['txt_clean'] = df['txt_clean'].apply(removeTermosDiferenciados)

#%%

text = " ".join(str(x) for x in df['txt_clean'].to_list())

wordcloud = WordCloud(max_font_size=50, max_words=20, background_color="black").generate(text)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()


word_list = text.split(' ')

#%%

df_count = pd.DataFrame({'words':word_list})

a = df_count['words'].value_counts().to_dict()

b = getFrequencyDictForText(text)
#%%
from gensim.models import KeyedVectors

model = KeyedVectors.load_word2vec_format('/Users/lmontesanti/Documents/lab_nlp/embeddings/glove_s100.txt')




#%%
result = model.most_similar(positive=['mulher', 'rei'], negative=['homem'])
most_similar_key, similarity = result[0]  # look at the first match
print(f"{most_similar_key}: {similarity:.4f}")

x = model['vaca']
b = model['amarela']

c = model.get_vector('azul')


#%%



#%%

a = model.infer_vector(['o', 'rato', 'fugiu', 'do', 'restaurante'])


#%%


#%%

tokens = ['o', 'luis', 'e', 'uma', 'pessoa', 'muito', 'simpatica']


minha_matriz = []
for t in tokens:
    vetor = model.get_vector(t)
    minha_matriz.append(vetor)
    
    
#%%

sentence_obama = 'Esse sistema e ruim'.lower().split()
sentence_obama2 = 'Esse sistema e bastante funcional'.lower().split()
sentence_president = 'O luis é uma pessoa muito simpativa'.lower().split()

similarity = model.wmdistance(sentence_obama, sentence_president)
print(f"{similarity:.4f}")


#%%

from pyemd import emd

#%%

import spacy
model = spacy.load('/Users/lmontesanti/output_glove')

#%%

a = model('bacana')
b = model('legal')

print(a.similarity(b))
#print(a.similarity(c))

#print(model('eu sou bacana').vector)

#%%
def getVector(x):
    new_vector = model(x).vector
    return new_vector
#%%
df['vec'] = df['txt_clean'].apply(lambda x: getVector(x))

X = df['vec'].to_numpy()

X = X.reshape(-1, 1)

X = np.concatenate(np.concatenate(X, axis = 0), axis = 0).reshape(-1, 100)
#%%

new_df = pd.DataFrame(X)

new_df['nota'] = df['nota']

new_df['nota'] = new_df['nota'].fillna(-5)

#%%

scaler = preprocessing.MinMaxScaler()
lista_colunas_teste = new_df.columns.tolist()
df_radom = scaler.fit_transform(new_df[lista_colunas_teste])

df_pi = pd.DataFrame(df_radom, columns=lista_colunas_teste)
#%%
new_df['nota'] = df_pi['nota']

#%%
eubou_metodo(new_df, 40)

#%%

base_model = X.copy()
kmeanModel = KMeans(n_clusters=6).fit(base_model)
y = kmeanModel.predict(base_model)


#%%


df_cluster = df.copy()
df_cluster['cluster'] = y

#%%

print(df_cluster['cluster'].value_counts())


a = df_cluster[df_cluster['cluster']==2]


#%%

for cluster in df_cluster['cluster'].unique():
    a = df_cluster[df_cluster['cluster'] == cluster]
    
    text = " ".join(str(x) for x in a['txt_clean'].to_list())

    wordcloud = WordCloud(max_font_size=50, max_words=20, background_color="black").generate(text)
    plt.figure()
    plt.title(f'meu cluster {cluster}')
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis("off")
    plt.show()
    
#%%

for cluster in df_cluster['cluster'].unique():
    a = df_cluster[df_cluster['cluster'] == cluster]
    a['nota'].value_counts(normalize=True).sort_index(ascending=False).plot.barh(title=f'Esse é o cluster {cluster}')
    
    plt.show()
    
#%%



    
#%%

total = df_cluster['nota'].value_counts()
for cluster in df_cluster['cluster'].unique():
    
    a = df_cluster[df_cluster['cluster'] == cluster]['nota'].value_counts()/total
    ax = a.plot.barh(title=f'Esse é o cluster {cluster}')
    ax.set_xlabel("Porcentagem")
    ax.set_ylabel("Nota")
    plt.show()

#%%

def similaridade(text, word):
    text_model = model(text)
    word_model = model(word)
    similarity = text_model.similarity(word_model)
    
    return similarity

#%%

df_cluster['positivo'] = df_cluster['txt_clean'].apply(lambda x: similaridade(x, 'plataforma bem organizada completa  boa visualizacao  praticidade facil navegacao '))
df_cluster['negativo'] = df_cluster['txt_clean'].apply(lambda x: similaridade(x, 'plataforma terrivel uso complicado e dificil'))

df_cluster['tag'] = np.where(df_cluster['positivo'] > df_cluster['negativo'], 1, 0)

#%%

print(df_cluster['tag'].value_counts())

#%%

for cluster in df_cluster['cluster'].unique():
    a = df_cluster[df_cluster['cluster'] == cluster]
    a['tag'].value_counts(normalize=True).sort_index(ascending=False).plot.barh(title=f'Esse é o cluster {cluster}')
    
    plt.show()
    
#%%

for cluster in df_cluster['tag'].unique():
    a = df_cluster[df_cluster['tag'] == cluster]
    
    text = " ".join(str(x) for x in a['txt_clean'].to_list())

    wordcloud = WordCloud(max_font_size=50, max_words=20, background_color="black").generate(text)
    plt.figure()
    plt.title(f'meu cluster {cluster}')
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis("off")
    plt.show()

#%%

df_cluster['tag'] = np.where(df_cluster['nota'] > 3, 1, 0)

#%%

df_pre_train = df_cluster.copy()

#df_pre_train = df_pre_train.dropna()

df_pre_train = df_pre_train[df_pre_train['txt_clean'].str.len() > 0]

df_pre_train = df_pre_train.reset_index()

X = df_pre_train['vec'].to_numpy()

X = X.reshape(-1, 1)

X = np.concatenate(np.concatenate(X, axis = 0), axis = 0).reshape(-1, 100)

df_train = pd.DataFrame(X)
df_train['tag'] = df_pre_train['tag']

#%%

df_train.to_csv('nlp_train.csv', sep=';')

#%%
#Transform df sentence to word

word_df = df.copy()
a = word_df['txt_clean'].str.split(expand=True).stack()

df_agg = pd.DataFrame({
    'sentence': a.index.get_level_values(0) + 1, 
    'word': a.values
})


#%%

word_df = df.copy()
word_df['lista_palavras'] = word_df['txt_clean'].str.split()

df_xpto = word_df[['id', 'lista_palavras']].copy()

df_agg = df_xpto.explode('lista_palavras')
df_agg = df_agg[df_agg['lista_palavras'].isnull() == False]

#%%
df_agg['vec'] = df_agg['lista_palavras'].apply(lambda x: getVector(x))
df_agg= df_agg.reset_index(drop=True)

#%%


#%%

X = df_agg['vec'].to_numpy()

X = X.reshape(-1, 1)

X = np.concatenate(np.concatenate(X, axis = 0), axis = 0).reshape(-1, 100)

df_train = pd.DataFrame(X)

#%%

df_left = pd.merge(df_agg, df_train, left_index=True, right_index=True ,how='left')

df_tranform = df_left.drop(['vec', 'lista_palavras'], axis=1)

#%%

lista_agg = ['min', 'max','mean','median','std']
pub_janela = df_tranform.groupby('id').agg(lista_agg)
#%%
lista_colunas = []
xx = len(pub_janela.columns)
for x in range(0,xx):
    x = 'c' + str(pub_janela.columns[x][0])  + '_' + str(pub_janela.columns[x][1])
    lista_colunas.append(x)
pub_janela.columns = lista_colunas
pub_janela = pub_janela.reset_index()


#%%
cluster_df = pub_janela.drop(['id'], axis=1).copy()
cluster_df = cluster_df.fillna(0)
      
eubou_metodo(cluster_df, 40)


#%%

kmeanModel = KMeans(n_clusters=5).fit(cluster_df)
y = kmeanModel.predict(cluster_df)

pub_janela['tag'] = y

#%%
print(cluster_df['tag'].value_counts())


#%%
df_tag = pub_janela[['id', 'tag']].copy()

final_df = pd.merge(word_df, df_tag, on='id', how='left')

#%%

print(final_df['tag'].value_counts())

a = final_df[final_df['tag'] == 3]